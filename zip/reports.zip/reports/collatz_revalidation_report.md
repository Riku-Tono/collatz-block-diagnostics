# Collatz reach-cliff revalidation

Date: 2026-06-25

## Definitions

Let `N = 2^p` and, for odd `n`,

```text
next_odd(n) = (3n + 1) / 2^v2(3n+1)
```

For a bit-length layer `b`, define:

```text
h = p - b
R(h,N) = 1 - reach(h,N)
Q(h,N) = 2^h R(h,N)
```

Two different boundary conditions were tested.

### odd-only

`ESCAPE` occurs only when an odd Syracuse node exceeds `N`.

### full-peak

`ESCAPE` occurs when either an odd node or the raw intermediate value
`3n+1` exceeds `N`.

These are different observables.

## Implementation checks

- The memoized `odd-only` implementation matched a direct, un-memoized
  trajectory calculation for every odd start at `p=4..16`.
- The memoized `full-peak` implementation passed the same check at
  `p=4..15`.
- For every aggregated layer at `p=28`, mod 8, 16, and 32 totals and
  reached counts summed exactly to the corresponding unpartitioned counts.
- All four Python files compiled successfully.

## Main finding

The reported discrepancy:

```text
Codex odd-only Q       about 0.61
Claude reported Q      about 1.87
```

is reproduced by changing the boundary condition.

At `p=26`, `h=3`:

```text
odd-only Q   = 0.614414
full-peak Q  = 1.878235
ratio        = 3.056952
```

The Claude-like mod 8 values are also reproduced by `full-peak`:

```text
residue mod 8   odd-only Q   full-peak Q
1               0.460403     1.395767
3               0.460815     1.395767
5               0.146683     0.466202
7               1.389755     4.255203
```

Thus the factor near 3 is not evidence of a random numerical bug.
It is primarily a boundary-definition difference: whether the even
peak `3n+1` is constrained by the finite window.

## N dependence

For `odd-only`, fixed low `h` values stabilize near `0.60-0.63`.

At `p=28`:

```text
h   Q
0   0.604535
1   0.628727
2   0.623922
3   0.619671
4   0.618523
5   0.614456
```

For `full-peak`, the interior cliff values stabilize near `1.86-1.89`.

At `p=28`:

```text
h   Q
1   1.789416
2   1.890610
3   1.875709
4   1.858688
5   1.861069
6   1.839172
```

This supports an exponent near 1 for both observables over the measured
range, but does not by itself prove an asymptotic theorem.

## Residue hierarchy

The mod 8 split persists as `p` increases. It does not disappear when
refined to mod 16 or mod 32; instead it becomes more structured.

For `odd-only`, `p=28`, `h=3`, mod 32 values range from:

```text
minimum Q = 0.03719  at residue 21
maximum Q = 3.12155  at residue 31
```

This is consistent with increasingly long deterministic low-bit
prefixes becoming visible. No closed form was established here.

## Remaining cautions

- `p=30` was not exhaustively run. With this exact implementation it
  would require roughly four times the `p=28` work and substantially
  more memory.
- The numerical exponent being close to 1 is an observation, not a
  proof for the actual Collatz map.
- The mod 16/32 hierarchy is real in these computations, but its
  asymptotic interpretation remains open.
- A claimed prefactor must always state whether it uses `odd-only` or
  `full-peak`; otherwise `0.61` and `1.87` appear contradictory when
  they are not.

## Files

- `collatz_revalidation.csv`: combined exact aggregates for the tested
  powers, boundary definitions, and mod 8/16/32 partitions.
- Working implementations remain in `work/`.
