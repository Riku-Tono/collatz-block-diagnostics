# Collatz Survival Operator

Date: 2026-06-25

Definition:

```text
S_p(K,h) = actual finite escape mass with K_tau=K
           / iid escape mass with K_tau=K
x = K - (p-h)
```

This is a localization diagnostic, not a proof of a causal mechanism.

## Reproducibility

- powers: [24, 25, 26, 27, 28]
- h values: [2, 3, 4, 5, 6]
- iid samples per h: 500000
- random seed: 20260625
- status caches: existing `odd_only_status_p*.bin` files under the 2026-06-25 Codex work folders

## Collapse Summary

| x=K-(p-h) | S collapsed | actual mass | iid mass |
|---:|---:|---:|---:|
| -4 | 0.997009 | 0.035903275 | 0.036010991 |
| -3 | 0.999730 | 0.029697239 | 0.029705247 |
| -2 | 0.998811 | 0.031583786 | 0.031621389 |
| -1 | 1.002681 | 0.025536358 | 0.025468069 |
| 0 | 0.996183 | 0.023642004 | 0.02373259 |
| 1 | 0.996787 | 0.025298893 | 0.025380446 |
| 2 | 0.994818 | 0.019857287 | 0.019960715 |
| 3 | 1.007492 | 0.019545734 | 0.019400391 |
| 4 | 1.000411 | 0.020629108 | 0.020620628 |
| 5 | 1.003042 | 0.016820788 | 0.01676978 |
| 6 | 1.000936 | 0.017391026 | 0.017374761 |
| 7 | 1.002692 | 0.015545726 | 0.01550399 |
| 8 | 1.013238 | 0.014029264 | 0.013845969 |

## Output Files

- `collatz_survival_operator_by_K.csv`
- `collatz_survival_operator_collapse_by_h.csv`
- `collatz_survival_operator_collapse_all.csv`
- `collatz_survival_operator_collapse.png`
- `collatz_survival_operator_parity.png`

Read ratios in very small iid-mass tails cautiously; those cells are dominated by finite counts and Monte Carlo tail noise.