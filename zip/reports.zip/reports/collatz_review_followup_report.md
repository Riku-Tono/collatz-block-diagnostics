# Collatz Review Follow-up

Date: 2026-06-25

## Scope

This follow-up weakens the causal wording.  The verified claim is localization: the actual-minus-iid deficit is concentrated in the exhaustion region `K_tau >= p-h`. It does not claim that finite-bit exhaustion is the unique cause.

The exact re-aggregation here uses the existing p=24..28 CSV outputs.  No p=29/p=30 exact status cache was available in this workspace.

## Reproducibility metadata

- Source script: `C:/Users/yauki/Documents/design/Collatz/py/py/collatz_escape_word_deficit.py`
- Original command shape: `python collatz_escape_word_deficit.py --powers 24 25 26 27 28 --hs 2 3 4 5 6 --depths 4 6 8 10 --iid-samples 500000 --seed 20260625`
- iid samples: 500000
- random seed: 20260625
- status cache used by source default: `C:/Users/yauki/Documents/Codex/2026-06-25/new-chat-2/work/status_cache`
- p,h range re-aggregated here: p=24..28, h=2..6
- max actual mass conservation error: 0.000e+00
- max iid mass conservation error: 5.144e-13

## Outputs

- `collatz_review_strata_summary_p24_p28.csv`: actual Q, iid Q, stratum ratios, exhausted contribution, and net deficit.
- `collatz_review_parity_by_stratum_p24_p28.csv`: even/odd comparison overall and within each K_tau stratum.
- `collatz_review_mass_conservation_p24_p28.csv`: mass preservation check for the strata split.
- `collatz_review_absorption_sampling_comparison.csv`: front, equal-spaced, and seed-fixed random cylinder sampling comparison.

## Interim judgment

Strong: deficit localization in `K_tau >= p-h`; near-unit actual/iid ratio in `K_tau < p-h`; short valuation cylinder realization counts match finite-layer expectations.

Not established: finite-bit exhaustion as the unique cause; asymptotic p-parity; causal mod-3 cutoff mechanism.
