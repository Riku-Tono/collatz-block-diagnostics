# Collatz mod-splitting mechanism audit

Date: 2026-06-25

## Fixed observable

This note continues the previous revalidation, using the same baseline observable:

- `N = 2^p`
- odd-only Syracuse orbit
- escape means some odd Syracuse node exceeds `N`
- reach means the odd orbit reaches `1` before exceeding `N`
- `h = p - bit_length(n)`
- `Q = (1 - reach) * 2^h`

The main run here uses `p=26, h=3`.

## First correction: mod 32 is not a one-arrow graph

For an odd residue `a mod 32`, the expression

```text
T(a) = (3a + 1) / 2^v2(3a+1) mod 32
```

using only the representative `a` is not a valid deterministic transition for the full residue class.

Reason: after dividing by `2^k`, higher bits of `n` affect the result modulo 32. So the correct object is a weighted transition distribution measured over the actual layer, not a single directed edge.

This matters especially because the mechanism we are looking for lives exactly in those discarded low bits.

## Experiment 1: first-step k is real but insufficient

At `p=26, h=3, mod 32`, each residue has a first-step `k = v2(3n+1)` distribution. Most classes have deterministic `k`; residue `21 mod 32` has a geometric tail:

```text
21 mod 32:
k=5: 1/2
k=6: 1/4
k=7: 1/8
...
mean k ~= 6
```

This already explains why `21 mod 32` is unusually safe: it usually shrinks hard on the first step.

But first-step `k` alone does not explain the whole split. For example several classes have `k=1`, yet their Q values differ strongly.

Correlation with `log2(Q)`:

```text
mean first-step k vs log2(Q):  -0.689894
```

So the first step is informative, but not the mechanism by itself.

## Experiment 2: weighted residue transition graph

The measured transition graph is branching, not functional.

Examples:

- `k=1` classes usually split into 2 target residues.
- `k=2` classes split into 4 target residues.
- `k=3` classes split into 8 target residues.
- `21 mod 32` has a high-k tail and 16 observed target residues in this layer.

The SVG graph in the outputs shows only edges with probability at least `0.12`, to avoid a hairball. The complete transition matrix is in the CSV.

## Experiment 3: one-step boundary approximation fails here

For `p=26, h=3`, immediate boundary crossing is not the source of the split:

```text
one-step odd escape rate  = 0 for all mod32 classes
one-step peak escape rate = 0 for all mod32 classes
```

That is expected because this layer is far enough below `N` that `3n+1` still stays under `N` at the first step.

So the mod split is not just "some residues cross the wall immediately."

## Experiment 4: depth-4 low-bit prefix explains the mod32 hierarchy

The decisive quantity is the local low-bit prefix over several Syracuse steps.

At `mod 32`, `d=4` average `k` almost completely orders the Q values.

Correlation with `log2(Q)`:

```text
d=1 mean k:  -0.689894
d=2 mean k:  -0.905948
d=3 mean k:  -0.985347
d=4 mean k:  -0.999888
```

The mod32 classes collapse into a clean five-level hierarchy:

```text
d4 mean k   residues                         Q range
1.0         31                               3.1192
1.5         7, 9, 15, 27                    1.0461 - 1.0510
2.0         1, 11, 19, 23, 25, 29           0.3381 - 0.3450
2.5         3, 5, 13, 17                    0.1069 - 0.1104
3.0         21                               0.0342
```

This is the core result.

In plain language:

> The big mod32 split is mostly determined by how much the first four odd Syracuse steps expand or shrink the number.

The extreme cases now have a mechanism:

- `31 mod 32`: four-step prefix is maximally expansion-heavy; mean `k = 1`, so it is the most escape-prone.
- `21 mod 32`: first step has a high `k` tail and the four-step prefix is strongly contraction-heavy; it is the safest class.

## Mod64 check

The same pattern survives refinement to `mod 64`.

Correlation with `log2(Q)`:

```text
d=1 mean k:  -0.631164
d=2 mean k:  -0.851572
d=3 mean k:  -0.958055
d=4 mean k:  -0.993934
```

So the mod64 split is also mostly a low-bit-prefix effect.

However, mod64 also shows that depth 4 is not the final closed form. For example:

```text
31 mod 64: Q = 1.5712, d4 mean k = 1.0
63 mod 64: Q = 4.6672, d4 mean k = 1.0
```

Both have the same four-step mean `k`, but their Q differs by about 3x. This means the next layer of splitting requires a deeper prefix or a more exact path functional than just depth-4 mean `k`.

So the honest statement is:

> depth-4 k-prefix almost completely explains the coarse mod32 hierarchy, and strongly explains mod64, but mod64 still contains finer unresolved structure.

## Current answer to "what determines Q?"

For the measured `odd-only, p=26, h=3` observable:

1. It is not explained by direct one-step boundary crossing.
2. It is not a single deterministic `mod32 -> mod32` transition.
3. The strongest explanatory variable found is the cumulative low-bit Syracuse prefix, especially mean `k` over the first 3-4 odd steps.
4. `Q_31 >> Q_21` is therefore not mysterious at the residue-label level: `31` is locally expansion-heavy, while `21` is locally contraction-heavy.
5. A closed form for the prefactor is not established. The mod64 residual split shows that "depth 4 mean k" is a strong descriptor, not a final theory.

## Output files

- `collatz_mod32_features.csv`
- `collatz_mod32_transitions.csv`
- `collatz_mod32_correlations.csv`
- `collatz_mod32_transition_graph.svg`
- `collatz_mod64_features.csv`
- `collatz_mod64_transitions.csv`
- `collatz_mod64_correlations.csv`
- `collatz_mod64_transition_graph.svg`
