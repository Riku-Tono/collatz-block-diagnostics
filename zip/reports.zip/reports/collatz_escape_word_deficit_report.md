# Escape-word localization of the finite deterministic correction

Date: 2026-06-25

## 1. Fixed observable and comparison

The observable is the odd-only Syracuse orbit with boundary `N=2^p`:

```text
ESCAPE = the odd orbit first produces an odd node > N
REACH  = the odd orbit reaches 1 without doing so.
```

The main exact calculation uses `p=28`, `h=2..6`.  The parity check uses
`p=24..28`.  Actual counts are exact from the status arrays.  The iid model is
sampled under the exponentially tilted escape law and reweighted to the
unconditional iid escape mass.  Thus a word is compared using

```text
actual escape count / finite layer size
versus
iid unconditional escape probability of the same word.
```

This is deliberately different from comparing only escape-conditioned shapes.

## 2. Main result: the deficit is localized in the bit-budget exhaustion region

Let `K_tau=sum(k_1,...,k_tau)` and let the input bit budget be `p-h`.

At `p=28`:

| h | actual Q | iid Q | actual/iid, K_tau < p-h | actual/iid, K_tau >= p-h | Q difference from exhausted stratum |
|---:|---:|---:|---:|---:|---:|
| 2 | 0.623922 | 0.624883 | 1.0005 | 0.9855 | -0.001234 |
| 3 | 0.619671 | 0.622461 | 0.9994 | 0.9838 | -0.002513 |
| 4 | 0.618523 | 0.624561 | 0.9984 | 0.9779 | -0.005445 |
| 5 | 0.614456 | 0.624100 | 1.0035 | 0.9700 | -0.010587 |
| 6 | 0.607910 | 0.623278 | 1.0087 | 0.9631 | -0.016818 |

The net Q differences are `-0.000961, -0.002791, -0.006038,
-0.009644, -0.015368`.  The exhausted stratum supplies about 90% to 128% of
the net negative difference; values above 100% occur because the within-budget
stratum has a small compensating positive difference.

This is the first direct localization of the deficit.  It is not just a
correlation with h: after cutting the same escape distribution by
`K_tau >= p-h`, the within-budget mass is approximately correct while the
exhausted mass is systematically low.

## 3. Prefix distributions

For fixed prefixes, the escape-conditioned total-variation distances at
`p=28, L=4` are:

| h | TV | smoothed KL (nats) |
|---:|---:|---:|
| 2 | 0.00597 | 0.00095 |
| 3 | 0.00580 | 0.00115 |
| 4 | 0.00941 | 0.00259 |
| 5 | 0.01740 | 0.00598 |
| 6 | 0.03041 | 0.01510 |

The early conditioned shape remains close to iid.  TV grows with h and depth,
but the `L=8,10` values increasingly include sparse-word sampling noise,
especially because the actual h=6 escape set has only 9,960 paths.  They should
be read as diagnostics, not asymptotic distances.

Examples of the largest `L=10` Q-contribution deficits at p=28 are:

| h | prefix | actual/iid | Q contribution difference |
|---:|:---|---:|---:|
| 2 | `2,1,1,1,1,1,1|E` | 0.9735 | -0.000172 |
| 3 | `1,2,1,1,1,1,1,1|E` | 0.9768 | -0.000232 |
| 4 | `1,1,1,1,1,1,1|E` | 0.9869 | -0.000211 |
| 5 | `1,1,2,1,1,1,1,1,1,1` | 0.9647 | -0.000314 |
| 6 | `1,1,1,2,1,1,1,1,1,1` | 0.9019 | -0.000870 |

No single short prefix carries the correction.  The deficit is distributed
over many expansion-heavy continuations.

## 4. Finite positive-integer cylinder test

A valuation prefix with cumulative `K` fixes exactly one odd residue cylinder
modulo `2^(K+1)`.  For every one of the 200 inspected top-deficit prefixes
(`L=4,6,8,10`, p=28), the exact number of representatives in the finite bit
layer equaled the iid cylinder expectation:

```text
finite realization count / iid expected realization count = 1.000000.
```

Therefore the correction is **not** caused by missing early residue cylinders.
The finite layer contains the expected starts for these prefixes.

The failure appears later: once `K_tau` approaches or exceeds `p-h`, the iid
2-adic continuation asks for bits that the finite positive integer no longer
has.  Its high bits are fixed at zero, so different nominal iid continuations
collapse onto the same finite starts or are replaced by other continuations.

The complete-word table illustrates the granularity.  At h=6, several iid
escape words have an expected count below one and zero actual occurrences,
even though their parent valuation cylinders have the exact expected finite
representatives.  This is a long tail of many tiny word-level deficits, not one
forbidden common word.

The complete-word ranking is support-discovered by one million tilted paths.
It is useful for identifying individual examples but is not an exhaustive sum
over the infinite full-word support.  The bit-budget aggregate above is the
more reliable conclusion.

## 5. Absorption and coalescence

Finite starts in top-deficit complete-word cylinders do not all have one fate.
For example at h=6:

- some cylinders with zero occurrences of the named iid word escape through a
  different valuation continuation;
- some representatives immediately or eventually enter a lower known orbit;
- the remaining nonescapes coalesce below the current bit layer and then reach
  1.

Thus absorption/coalescence is a real endpoint of part of the displaced mass,
but it is not an independent explanation of the whole deficit.  Missing iid
word labels can also be rerouted to another escaping word.  The more primitive
event is loss of independent high-bit continuation after the budget is spent.

The classification CSV is conditional on selected top-deficit cylinders and
the cylinders can overlap.  Its rows must not be summed into a global causal
percentage.

## 6. p-parity diagnosis

Using the same iid reference for p=24..28, the mean even-p minus odd-p Q
deficit is:

| h | even-p mean deficit | odd-p mean deficit | even minus odd |
|---:|---:|---:|---:|
| 2 | -0.002551 | +0.000197 | -0.002748 |
| 3 | -0.006032 | +0.000204 | -0.006236 |
| 4 | -0.014385 | -0.000011 | -0.014374 |
| 5 | -0.024485 | -0.004929 | -0.019557 |
| 6 | -0.038643 | -0.001269 | -0.037374 |

The period-two pattern is large and grows with h.  It is spread over many
prefixes rather than one stable exceptional word.  This is consistent with a
cutoff-wide arithmetic modulation, possibly involving
`2^p mod 3 = (-1)^p mod 3`, acting on the exhausted high-bit tail.

There are only three even and two odd powers in this comparison.  The pattern
is real in the computed window, but a causal mod-3 derivation and persistence
beyond p=28 are not established.

## 7. Classification of Delta_det

### A. Exhaustion-region localization: strongest current classification

Supported directly as localization, not as a completed causal explanation. Almost all net negative mass is localized in K_tau >= p-h; the within-budget actual/iid ratio stays near one. The correct wording is not that short residue cylinders are absent, nor that finite-bit exhaustion has been proven the unique cause, but that the observed deficit is concentrated where the iid 2-adic continuation would require more bits than the finite start supplies.

### B. Absorption or coalescence: secondary observed endpoint

Present among displaced finite starts, but the classification is conditional on selected cylinders and is sensitive to sampling scheme. Equal-spaced and seed-fixed random samples can differ substantially from front-of-cylinder samples. B should be treated as an observed endpoint in selected cylinders, not as a standalone global quantitative law.

### C. Long-range valuation correlation: not ruled out, but sharpened

No large discrepancy is visible in short-prefix marginals or lag-1 behavior. If dependence is present, the current evidence points to a long-range deterministic continuation constraint in the exhaustion region rather than a generic stationary low-order k-correlation.

### D. Cutoff arithmetic: candidate modifier, not yet derived

The p-even/p-odd split is substantial in the computed window and increases with h. Within-stratum re-aggregation shows that most of this even-minus-odd deficit remains in the exhausted stratum, while the within-budget stratum has smaller differences that sometimes change sign. This supports only candidate parity modulation concentrated in the exhaustion region. It does not establish an asymptotic period-two law or a causal mod-3 mechanism.

## 8. Careful conclusion

The best current classification is:

```text
Delta_det is localized in the K_tau >= p-h exhaustion region (A),
            with candidate cutoff parity/arithmetic modulation (D),
            and absorption/coalescence (B) as one observed downstream fate.
```

The data do not support a single missing prefix or a simple low-order valuation correlation. They support a collective deficit concentrated in the high-cumulative-valuation escape tail precisely where the iid 2-adic model asks for more bits than the finite start contains. This is a localization result, not a proof of a unique cause.

## 9. Review follow-up addendum

The causal wording has been weakened. The supported claim is now localization:

```text
deficit is concentrated in the region K_tau >= p-h.
```

The analysis does not claim that finite-bit exhaustion is the unique cause, that p-parity is asymptotic, or that a mod-3 cutoff mechanism has been derived.

Additional re-aggregation outputs were generated in C:/Users/yauki/Documents/Codex/2026-06-25/new-chat-3/outputs:

- collatz_review_strata_summary_p24_p28.csv
- collatz_review_parity_by_stratum_p24_p28.csv
- collatz_review_mass_conservation_p24_p28.csv
- collatz_review_absorption_sampling_comparison.csv
- collatz_review_followup_report.md

Reproducibility metadata for the re-aggregation:

```text
source script: C:/Users/yauki/Documents/design/Collatz/py/py/collatz_escape_word_deficit.py
command shape: python collatz_escape_word_deficit.py --powers 24 25 26 27 28 --hs 2 3 4 5 6 --depths 4 6 8 10 --iid-samples 500000 --seed 20260625
iid samples: 500000
random seed: 20260625
status cache: C:/Users/yauki/Documents/Codex/2026-06-25/new-chat-2/work/status_cache
p,h range: p=24..28, h=2..6
max actual mass conservation error: 0.000e+00
max iid mass conservation error: 5.144e-13
```

### Parity within strata

For p=24..28, the even-minus-odd deficit remains mostly in the exhausted stratum. In the within-budget stratum the even/odd differences are small and sometimes change sign. This supports only a candidate parity modulation concentrated in the exhaustion region. It does not establish an asymptotic period-two law.

### Absorption/coalescence sampling

The old cylinder classification used front-of-cylinder samples. Equal-spaced and seed-fixed random samples can differ substantially from the front samples. Therefore absorption/coalescence should be treated as an observed endpoint in selected cylinders, not as a global quantitative decomposition.

### p=29 and p=30

No p=29 or p=30 exact status cache was available in the current workspace. With only stock Python available, exact p=29/p=30 strata computation would require tracing tens to hundreds of millions of odd starts or building very large status arrays. To avoid another runaway run, these powers were not recomputed in this follow-up. They remain the next priority for a compiled or cached exact run.
