# Odd-only Collatz finite-window residue model

Date: 2026-06-25

## 1. Observable and local dynamics

Let

```text
N = 2^p
T(n) = (3n + 1) / 2^k(n)
k(n) = v2(3n + 1)
```

on odd integers. For starts in the bit layer

```text
bit_length(n) = p - h
```

define the odd-only escape probability in an odd residue class `r mod 2^s` by

```text
R_r(p,h;2^s)
  = P(an odd Syracuse node exceeds N
      | bit layer h, n = r mod 2^s)
```

and

```text
Q_r(p,h;2^s) = 2^h R_r(p,h;2^s).
```

The unpartitioned quantities are denoted by `R(p,h)` and `Q(p,h)`.

For a Syracuse path `n_0=n, n_{i+1}=T(n_i)`, write

```text
k_i = v2(3n_{i-1}+1)
K_d = k_1 + ... + k_d
M_d = 3^d / 2^K_d.
```

The exact iterate has the affine form

```text
n_d = (3^d n + B_d) / 2^K_d,
```

where `B_d` depends on the valuation prefix. For large starts,

```text
n_d = n M_d + a lower-order additive term,
```

so `M_d` is the local multiplicative scale change.

For a uniformly random 2-adic lift of the odd class `r mod 2^s`, define

```text
A_r(d)
  = E[M_d | n = r mod 2^s]
  = E[3^d / 2^K_d | n = r mod 2^s].
```

## 2. Why the expected multiplier enters the escape prefactor

The measured unpartitioned escape tail has the approximate exponent-one form

```text
R(p,h) approximately C(p,h) 2^(-h).
```

Suppose a short local prefix multiplies the starting scale by `M_d`. Ignoring the additive term and early boundary crossing, the effective distance below the window changes from `h` to

```text
h_d approximately h - log2(M_d).
```

Applying the same global tail after the local prefix gives

```text
R_r(p,h)
  approximately E[C(p,h) 2^(-h_d) | r]
  approximately C(p,h) 2^(-h) E[M_d | r].
```

Multiplying by `2^h` yields

```text
Q_r(p,h;2^s) approximately C(p,h) A_r(d).
```

Thus the residue class does not introduce a separate escape law. It locally shifts the scale through its low-bit Syracuse prefix; the remaining finite-window escape tail is represented by the residue-independent factor `C(p,h)`.

This is a first-order transfer heuristic. It assumes that, after the low-bit prefix has been consumed, the remaining escape behavior is approximately the same global tail for every residue class.

## 3. Why the residue average of A is one

Equip the odd 2-adic integers with normalized Haar measure. For an odd 2-adic integer,

```text
P(k=j) = 2^(-j),  j=1,2,...
```

because one normalized odd residue class modulo `2^(j+1)` has `v2(3n+1)=j`.

Therefore the one-step expected multiplier is

```text
E[3 / 2^k]
  = 3 * sum_{j>=1} P(k=j) 2^(-j)
  = 3 * sum_{j>=1} 4^(-j)
  = 1.
```

More generally, a prescribed valuation word

```text
(k_1,...,k_d)
```

occupies one 2-adic cylinder of normalized measure

```text
2^(-(k_1+...+k_d)).
```

Consequently the valuation symbols have the geometric cylinder weights needed for

```text
E[M_d]
  = E[3^d / 2^K_d]
  = product over i of E[3 / 2^k_i]
  = 1.
```

Averaging the conditional expectation over all `2^(s-1)` odd residue classes gives the tower-property identity

```text
2^(-(s-1)) * sum_{r odd mod 2^s} A_r(d)
  = E[M_d]
  = 1.
```

This explains the numerical observations

```text
mean_r A_r(4), mod32 approximately 1
mean_r A_r(5), mod64 approximately 1.
```

The small numerical deviations from one came from finite lift enumeration and floating-point arithmetic.

## 4. Connection between C(p,h) and the unpartitioned Q

Each odd residue class has the same asymptotic density in a sufficiently large bit layer. Hence

```text
Q(p,h)
  = mean_r Q_r(p,h;2^s).
```

If the residue law holds,

```text
mean_r Q_r
  approximately C(p,h) mean_r A_r
  = C(p,h).
```

Therefore

```text
C(p,h) approximately Q(p,h).
```

This is why the fitted common factor and the unpartitioned Q agreed out of sample.

A small distinction is important:

- `mean_r A_r=1` connects the arithmetic residue mean of Q to C;
- `median_r(Q_r/A_r)` is a robust estimator of the common C when the individual ratios concentrate.

The equality of the mean multiplier does not, by itself, imply an identity involving the median. The observed median agreement is empirical evidence that the classwise ratios are tightly concentrated.

## 5. Why depth s-1 is natural

An odd residue modulo `2^s` contains `s-1` informative binary digits after odd parity is fixed.

A Syracuse odd step divides by `2^k` with `k>=1`. In the 2-adic symbolic description, the valuation branch consumes `k` low binary digits. Thus every odd step consumes at least one bit of the initial residue information.

This does **not** mean that `r mod 2^s` deterministically fixes `s-1` individual k values. For example, a residue may only imply `k>=s`, with the exact k supplied by higher lift bits.

The correct statement is:

> after at most `s-1` odd steps, the original `s-1` low bits cannot constrain any further valuation branch; any unresolved continuation is supplied by the Haar-random lift.

Since the expected multiplier of an unconstrained continuation is one, extending beyond this depth should not change the conditional expected multiplier:

```text
A_r(d) approximately A_r(s-1),  d >= s-1,
```

in the ideal 2-adic lift model.

This is exactly the observed stabilization:

```text
mod 32 = 2^5: A_r(d) and predictive power stabilize at d=4
mod 64 = 2^6: A_r(d) and predictive power stabilize at d=5.
```

So `s-1` is best interpreted as a maximal low-bit memory depth, not as a fully deterministic trajectory length.

## 6. Finite-window prefactor C(p,h)

The factor `C(p,h)` represents the residue-independent remainder of the finite-window first-passage problem after the local low-bit scale change has been factored out.

It may contain:

- the global odd-only escape-tail normalization;
- finite-p corrections;
- dependence on the layer offset h;
- longer-scale orbit behavior not encoded by the first `s-1` low-bit steps.

It is not assumed here to have an asymptotic limit.

The out-of-sample results support

```text
C(p,h) approximately Q(p,h)
```

in adequately sampled, non-saturated layers. At `p=28,h=2..6`, the fitted median ratios were approximately `0.603` to `0.620`, while the unpartitioned Q values were approximately `0.608` to `0.624`.

## 7. Applicability and failure conditions

### 7.1 Boundary saturation

Since an escape probability cannot exceed one,

```text
0 <= Q_r(p,h) <= 2^h.
```

The linear prediction `C A_r` can exceed this limit for strongly expanding residue classes near the boundary.

A schematic clipped correction is

```text
Q_r(p,h)
  approximately E[min(2^h, C(p,h) M_d) | r].
```

This expression is only schematic because true escape is a first-passage event and may depend on the maximum prefix multiplier

```text
max_{1<=j<=d} 3^j / 2^K_j,
```

not only on the terminal `M_d`.

The unclipped proportional law fails systematically at `h=1`; a weaker top-class clipping effect remains for mod64 at `h=2`.

### 7.2 Sparse escape observations

For contraction-heavy classes, the escape probability can be extremely small. At small p or large h, a finite layer may contain only a few escapes or none.

Then:

- some measured `Q_r` equal zero;
- logarithmic regression becomes incomplete;
- fitted slopes are unstable or inflated;
- `median(Q_r/A_r)` is biased downward.

This is an estimation failure of the finite enumeration, not evidence that the underlying local multiplier reverses its ordering.

### 7.3 Small-p and additive corrections

At small p:

- the affine additive term in `T^d(n)` is less negligible relative to n;
- the post-prefix orbit has less room to enter the global tail regime;
- residue classes contain fewer rare escape events.

These produce finite-window deviations from the scale-transfer approximation.

### 7.4 Observable dependence

The model here is specifically for the odd-only boundary. Constraining the raw even peak `3n+1` defines a different observable and a different global prefactor.

## 8. Empirical finite-window residue law

### Empirical finite-window residue law

For the odd-only finite-window observable, let

```text
N = 2^p,
bit_length(n) = p-h,
r odd mod 2^s,
d = s-1.
```

In non-saturated layers with enough residue-level escape observations,

```text
Q_r(p,h;2^s)
  approximately Q(p,h) A_r(s-1),
```

where

```text
A_r(s-1)
  = E[3^(s-1) / 2^K_(s-1)
      | n = r mod 2^s]
```

is the expected finite-depth Syracuse multiplier over 2-adic lifts.

Equivalently,

```text
Q_r(p,h;2^s)
  approximately C(p,h) A_r(s-1),
C(p,h) approximately Q(p,h).
```

The normalization follows from

```text
mean_r A_r(s-1) = 1
```

under the ideal odd 2-adic Haar model.

This is an **out-of-sample empirical finite-window law** supported for mod32/depth4 and mod64/depth5 over the measured non-saturated, well-sampled layers. It is not an asymptotic theorem, a proof of Collatz behavior, or a derived limit formula for `C(p,h)`.

