# Collatz residue prefactor law: out-of-sample validation

Date: 2026-06-25

## Verdict

The proportional law discovered at `p=26, h=3` survives out of sample:

```text
Q_r(p,h) ≈ C(p,h) * A_r(d)

mod 32: d = 4
mod 64: d = 5
```

It is not valid without qualifications at every finite `p,h`. It has a clear empirical operating range:

- it works very strongly once the layer has enough escape observations;
- it fails systematically at `h=1` because the largest predicted class values hit the finite bound `Q_r <= 2^h`;
- it degrades for large `h` at small `p`, where rare contraction-heavy classes have only a few escapes or zero observed escapes.

Within the well-sampled, non-saturated range, the result supports an **out-of-sample empirical law**, not a proof.

## Setup

Fixed before validation:

```text
observable = odd-only
mod 32 predictor = A_r(4)
mod 64 predictor = A_r(5)
A_r(d) = E[3^d / 2^K_d | n = r mod 2^s]
K_d = k_1 + ... + k_d
```

Validation grid:

```text
p = 20, 22, 24, 26, 28
h = 1, 2, 3, 4, 5, 6
```

The original discovery cell `p=26,h=3` is retained in the tables but explicitly marked `discovery`. Every other cell is validation.

For each `p`, the odd-only status array was computed once. Overall, mod32, and mod64 summaries were then aggregated from the same status data.

## Strongest out-of-sample result: p=28

### mod 32, fixed depth 4

| h | R2 | slope | median Q/A | overall Q |
|---:|---:|---:|---:|---:|
| 2 | 0.999970 | 1.0056 | 0.6187 | 0.6239 |
| 3 | 0.999951 | 1.0089 | 0.6186 | 0.6197 |
| 4 | 0.999934 | 1.0069 | 0.6117 | 0.6185 |
| 5 | 0.999417 | 1.0132 | 0.6083 | 0.6145 |
| 6 | 0.997309 | 1.0090 | 0.6033 | 0.6079 |

### mod 64, fixed depth 5

| h | R2 | slope | median Q/A | overall Q |
|---:|---:|---:|---:|---:|
| 2 | 0.995220 | 1.0092 | 0.6197 | 0.6239 |
| 3 | 0.999943 | 1.0087 | 0.6191 | 0.6197 |
| 4 | 0.999789 | 1.0080 | 0.6118 | 0.6185 |
| 5 | 0.998883 | 1.0126 | 0.6076 | 0.6145 |
| 6 | 0.996188 | 1.0025 | 0.6042 | 0.6079 |

Thus all ten `p=28, h=2..6` checks satisfy:

```text
R2 >= 0.995
slope between 1.0025 and 1.0132
no zero-Q residue classes
median Q/A within 0.0069 of overall Q
```

The original discovery value was not needed for this result.

## Behavior as p changes

Using the numerical criteria

```text
R2 >= 0.99
abs(slope - 1) <= 0.15
no zero-Q classes
```

the useful range expands with `p`.

| p | mod32 useful h | mod64 useful h | main limitation outside range |
|---:|:---|:---|:---|
| 20 | 2-3 | none at strict R2 cutoff | small p and sparse escapes |
| 22 | 2-3 approximately | none at strict R2 cutoff | sparse contraction-class escapes |
| 24 | 2-4 | 2-3 | sparse escapes at larger h |
| 26 | 2-5 | 2-5 | h=6 begins to contain zero/sparse classes |
| 28 | 2-6 | 2-6 | no sampling failure in tested range |

At `p=22,h=3,mod32`, `R2=0.99014` but the slope is `1.1513`, just outside the chosen slope tolerance. It is therefore borderline rather than a clean success.

## C(p,h) stability

Define

```text
C(p,h) = median_r Q_r / A_r(d)
```

At `p=28`, both moduli give nearly identical C values and track the unpartitioned Q:

```text
h    C_mod32   C_mod64   overall Q
2    0.6187    0.6197    0.6239
3    0.6186    0.6191    0.6197
4    0.6117    0.6118    0.6185
5    0.6083    0.6076    0.6145
6    0.6033    0.6042    0.6079
```

This agreement is structurally natural because the residue average of the fixed predictor is numerically one:

```text
mean_r A_r(4), mod32 = 0.9999999984
mean_r A_r(5), mod64 = 0.9999999995
```

At smaller `p`, C drifts downward for large `h`, exactly where the rarest residue classes have too few observed escapes. Therefore the observed C drift is consistent with finite sampling / finite-window effects; it is not evidence for a new residue-dependent constant.

The data do not establish an asymptotic limit for C.

## Rank preservation

The predictor A has only a few exact discrete levels, so ordinary Spearman correlation cannot reach 1 when Q gives slightly different values inside an A-tied group.

The theoretical tie ceilings are approximately:

```text
mod32: 0.958706
mod64: 0.965497
```

In the successful cells, observed Spearman is essentially at this ceiling. For example, at `p=28,h=3`:

```text
mod32 observed / ceiling = 0.958706 / 0.958706
mod64 observed / ceiling = 0.965674 / 0.965497
```

The small numerical excess in the second line reflects ties in the observed Q ranks; it is not interpreted as performance above a mathematical maximum.

At the group level, the A hierarchy is therefore fully preserved throughout the well-sampled range.

## Failure modes

### 1. Near-boundary saturation

For every tested p, `h=1` fails the linear shape test:

```text
mod32 R2 approximately 0.953
mod64 R2 approximately 0.925
```

This does not disappear at `p=28`, so it is not sampling noise.

The reason is that the proportional predictor can exceed the finite observable bound:

```text
Q_r <= 2^h
```

The expansion-heavy classes are clipped first. A weaker version also affects the top mod64 class at `h=2`, although the fit is already strong there.

### 2. Sparse escape counts

For large h at smaller p, contraction-heavy classes have very small escape probabilities. This produces:

- zero-Q classes;
- inflated slopes;
- unstable log fits;
- downward-biased median Q/A.

Examples include `p=20,h>=4`, `p=22,h>=4`, and the mod64 side of `p=24,h>=4`.

### 3. Small-p finite-window effects

Even before a class reaches exactly zero, small p can leave too few tail observations to estimate the proportional law at high precision. The failure recedes systematically as p increases.

## Final empirical statement

The data support the following restricted statement:

> For the odd-only finite-window observable, away from immediate boundary saturation and with enough residue-level escape observations, the residue prefactor is accurately predicted by the fixed low-bit expected multiplier:
>
> `Q_r(p,h) approximately C(p,h) A_r(s-1)`.
>
> This holds out of sample for mod32/depth4 and mod64/depth5, with slopes near one, near-perfect residue-level shape fits, and C close to the unpartitioned Q.

The strongest validation is `p=28,h=2..6`, where all tested cells pass the numerical shape criteria.

This is an **out-of-sample empirical law**. It is not a proof, a closed form for C, or an asymptotic Collatz theorem.

## Files

- `collatz_oos_metrics.csv`: all requested fit, C, rank, sample, and failure metrics.
- `collatz_oos_residue_q.csv`: all residue-level Q values.
- `collatz_oos_q_p20.csv` through `collatz_oos_q_p28.csv`: resumable per-power raw aggregates.

