# Finite-p,h corrections to the odd-only global prefactor

Date: 2026-06-25

## 1. Question and fixed reference

Fix

```text
C0 = 0.6235
Delta(p,h) = Q(p,h) - C0.
```

Here `C0` is the approximate layer-averaged iid Syracuse random-walk overshoot prefactor, not an established Collatz constant.

The main reliable window is

```text
p >= 24
2 <= h <= 6.
```

The purpose is to test whether the observed 0.61 band can be separated into

```text
iid layer-overshoot main term
+ finite-window / deterministic correction.
```

## 2. Residual table

The complete table for `p=18..28, h=0..10` is in `collatz_C_residuals.csv`. It includes Q, Delta, binomial standard error, escape count, `h/p`, and `2^(h-p)`.

The main high-p interior residuals are:

| p \ h | 2 | 3 | 4 | 5 | 6 |
|---:|---:|---:|---:|---:|---:|
| 24 | -0.001941 | -0.008296 | -0.018275 | -0.025844 | -0.043422 |
| 25 | +0.002684 | +0.002042 | +0.005925 | +0.000646 | +0.017125 |
| 26 | -0.001985 | -0.009086 | -0.016719 | -0.036769 | -0.057582 |
| 27 | +0.000475 | -0.003711 | -0.003825 | -0.009303 | -0.020106 |
| 28 | +0.000422 | -0.003829 | -0.004977 | -0.009044 | -0.015590 |

Two features are visible:

1. at fixed even p, the correction generally becomes more negative as h grows;
2. in the high-p window, odd p values are systematically above neighboring even p values.

The second feature is only a candidate period-two component; five high-p points are not enough to establish a log-periodic law.

## 3. h dependence at p=28

For `h=2..6`:

| h | Q | Delta=Q-C0 | binomial SE | Delta/SE |
|---:|---:|---:|---:|---:|
| 2 | 0.623922 | +0.000422 | 0.000354 | +1.19 |
| 3 | 0.619671 | -0.003829 | 0.000738 | -5.19 |
| 4 | 0.618523 | -0.004977 | 0.001506 | -3.30 |
| 5 | 0.614456 | -0.009044 | 0.003032 | -2.98 |
| 6 | 0.607910 | -0.015590 | 0.006062 | -2.57 |

A linear fit gives

```text
Delta(28,h) approximately 0.008292 - 0.003724 h
RMSE = 0.001244.
```

A quadratic fit lowers the RMSE to `0.000862`, but it uses three parameters for only five points. This is not enough evidence to claim curvature.

At fixed p, the forms `a+b h` and `a+b h/p` are algebraically identical after rescaling b. They cannot be distinguished from one p-slice.

The safest description is:

> at p=28, the correction is approximately linear and negative over h=2..6, with possible weak curvature not resolved by five points.

## 4. Pooled p>=24,h=2..6 fits

Unweighted residual RMSE values were:

| model | RMSE |
|:---|---:|
| constant | 0.01612 |
| a+b h | 0.01377 |
| a+b h/p | 0.01363 |
| a+b 2^(h-p) | 0.01454 |
| a+b/p+c h/p | 0.01362 |

The differences among the h and h/p models are small. The `2^(h-p)` model is not favored and requires an extremely large coefficient because the predictor is tiny.

The pooled fit is dominated by p-to-p structure and sparse-tail noise. It does not identify a unique correction law.

## 5. Fixed-h p dependence

For each h, the high-p window `p=24..28` was compared using:

```text
constant Delta
Delta = a/p, with zero asymptotic intercept
Delta = a 2^(-p), with zero asymptotic intercept
Delta = c + a/p.
```

Neither `1/p` nor `2^(-p)` gives a stable explanation:

- the through-zero `1/p` fit improves RMSE only marginally over a constant residual;
- the free intercept again varies strongly with h;
- the `2^(-p)` coefficients are huge and the RMSE is not consistently better.

Thus the data do not support a clean `O(1/p)` or `O(2^(-p))` correction.

## 6. High-p period-two candidate

On `p=24..28`, adding `b(-1)^p` to an intercept-plus-`1/p` fit gives:

| h | parity amplitude b | RMSE ratio versus no parity |
|---:|---:|---:|
| 2 | -0.00137 | 0.622 |
| 3 | -0.00311 | 0.638 |
| 4 | -0.00713 | 0.584 |
| 5 | -0.00971 | 0.682 |
| 6 | -0.01864 | 0.698 |

The negative sign means even p lies lower than odd p in this window. The amplitude increases with h.

This is a real pattern in the available exact data, but the evidence is limited:

- only five high-p powers are available;
- h=5,6 have larger sampling errors;
- low-p data do not follow one clean parity amplitude.

A natural arithmetic hypothesis is that the cutoff `N=2^p` alternates modulo 3 because

```text
2^p mod 3 = (-1)^p mod 3.
```

No causal derivation has been established. This should be called a **period-two boundary candidate**, not a detected asymptotic log-periodic correction.

## 7. Iid h=2..6 comparison

The iid importance sampler was rerun directly at nominal h=2..6 with 200,000 paths per h.

| h | iid layer C | Monte Carlo SE | actual Q(p=28) | actual - iid |
|---:|---:|---:|---:|---:|
| 2 | 0.625110 | 0.000313 | 0.623922 | -0.001188 |
| 3 | 0.622207 | 0.000312 | 0.619671 | -0.002537 |
| 4 | 0.624464 | 0.000319 | 0.618523 | -0.005941 |
| 5 | 0.624460 | 0.000315 | 0.614456 | -0.010004 |
| 6 | 0.623125 | 0.000314 | 0.607910 | -0.015215 |

The iid values fluctuate by about 0.003 but show no monotone downward trend. The actual-minus-iid deficit becomes increasingly negative.

Therefore the observed h slope is not explained by the one-bit layer average or by the iid overshoot phase alone.

## 8. Actual versus iid escape-path diagnostics

At p=28, actual escape starts were sampled uniformly from the exact escape set:

- 20,000 paths per h where available;
- all 9,960 escape paths at h=6.

The iid comparison used 50,000 exponentially tilted paths per h, reweighted back to the original escape-conditioned law.

### Conditional path summaries

| h | actual overshoot | iid overshoot | actual steps | iid steps | actual log2 affine correction |
|---:|---:|---:|---:|---:|---:|
| 2 | 0.25395 | 0.25180 | 10.44 | 10.52 | 1.9e-7 |
| 3 | 0.25957 | 0.25856 | 14.42 | 14.56 | 3.8e-7 |
| 4 | 0.25329 | 0.25473 | 18.20 | 18.55 | 7.2e-7 |
| 5 | 0.25586 | 0.25436 | 21.90 | 22.57 | 1.3e-6 |
| 6 | 0.25419 | 0.25682 | 25.85 | 26.47 | 2.4e-6 |

The escape-conditioned k statistics also nearly coincide:

```text
actual mean k approximately 4/3
actual P(k=1) approximately 3/4
actual and iid lag-1 k correlation approximately 0
maximum first-eight-position mean-k difference < 0.019
maximum first-eight-position P(k=1) difference < 0.013.
```

Unconditioned actual prefixes have

```text
mean k approximately 2
P(k=1) approximately 1/2
small measured lag-1 correlation.
```

### Overshoot and maximum-prefix distributions

The 10%, 50%, and 90% overshoot quantiles are almost identical between actual and iid paths. For example at h=6:

```text
actual overshoot quantiles: 0.0452, 0.2339, 0.4977
iid overshoot quantiles:    0.0426, 0.2385, 0.5037
```

Since the path is stopped at its first crossing, the final multiplier is also its maximum prefix multiplier. At h=6:

```text
actual max-multiplier quantiles: 73.978, 97.310, 138.552
iid max-multiplier quantiles:    73.978, 97.310, 138.552
```

Thus the shape of paths that do escape is extremely close to the iid tilted model.

The discrepancy is mainly in the **total probability mass of escaping paths**, not in the conditional shape after escape has been selected.

## 9. Candidate mechanism classification

### Affine +1 correction

Unlikely to explain the deficit.

The accumulated exact-minus-multiplicative correction is only `10^-7` to `10^-6` bits on sampled escape paths.

### Simple one-step or lag-1 valuation correlation

Not visible as the main cause.

Unconditioned prefixes are close to geometric iid, and escape-conditioned marginals and lag-1 correlations closely match the tilted iid law.

This does not rule out weak higher-order or long-range deterministic correlations. Small per-step deviations can accumulate over 10-26 steps.

### Overshoot distribution

Not the cause of the observed h slope.

Means and quantiles match closely, while total escape probabilities differ.

### Sampling error

Not sufficient by itself.

The p=28 actual-iid differences are approximately 2.5 to 3.9 combined standard errors for h=2..6. Sampling noise grows at h=5,6 but does not explain the full monotone deficit.

### Finite bit budget / 2-adic truncation

Plausible but not proven.

For an escape path, the valuation word consumes `K_tau` input bits. The probability that `K_tau` exceeds the initial bit length `p-h` rises strongly:

| h | actual P(K_tau >= p-h) | iid conditional value |
|---:|---:|---:|
| 2 | 0.134 | 0.135 |
| 3 | 0.242 | 0.247 |
| 4 | 0.390 | 0.398 |
| 5 | 0.552 | 0.567 |
| 6 | 0.722 | 0.735 |

Across these five h values, the correlation between the actual-iid Q deficit and the actual bit-budget-exhaustion fraction is about `-0.993`.

This correlation is not causal evidence because both quantities are monotone in h. Moreover, conditioned actual and iid paths have nearly the same K distribution.

Nevertheless it identifies the regime where the infinite random 2-adic lift becomes least faithful to finite positive integers: the valuation word requests more input bits than the start originally contains. Fixed zero high bits, orbit coalescence, absorption at 1, or other long-range deterministic constraints can then change the total number of available escaping words without changing the shape of the words that survive.

### Finite boundary arithmetic

Also plausible.

The high-p odd/even pattern suggests that the exact cutoff `2^p`, including its residue modulo 3, affects the total mass of admissible escape paths. More powers are required to separate a genuine period-two boundary correction from finite-sample fluctuation.

## 10. Current decomposition

The data support the working decomposition

```text
Q_r(p,h;2^s)
  approximately A_r(s-1)
              * [C_iid,layer(h) + Delta_det(p,h)].
```

Here

```text
A_r(s-1):
  explains low-bit residue splitting.

C_iid,layer(h):
  approximately 0.623 across h=2..6;
  supplies the first-passage exponent-one main scale.

Delta_det(p,h):
  small near p=28,h=2;
  increasingly negative with h for even p;
  contains finite-integer, long-range deterministic,
  and possibly period-two boundary corrections.
```

At present, `Delta_det` has not been reduced to a stable formula such as `a/p`, `a h/p`, or `a 2^(-p)`.

## 11. Explained versus unresolved

### Explained or strongly constrained

- iid layer/overshoot effects produce a nearly flat 0.623 main term;
- the observed actual h slope is not present in that iid term;
- affine `+1` corrections on escaping paths are negligible;
- simple k marginals, lag-1 correlations, overshoot, and maximum-prefix distributions are nearly iid after escape conditioning;
- sparse sampling contributes at larger h but is not the whole deficit;
- a high-p period-two boundary candidate exists.

### Still unresolved

- what removes the missing 0.2% to 2.4% of iid escape mass as h increases;
- whether the deficit is caused by higher-order valuation correlations, finite-bit truncation, absorption/coalescence, cutoff arithmetic, or a combination;
- whether the odd/even p pattern persists beyond p=28;
- whether `Delta_det(p,h)` vanishes at fixed h as p tends to infinity;
- a renewal model with the correct finite-integer correction.

The careful conclusion is:

> the 0.61 band can be usefully separated into an iid layer-overshoot main term near 0.623 and a measurable negative finite-window/deterministic correction. The main term is understood heuristically; the correction is localized but not yet derived.

