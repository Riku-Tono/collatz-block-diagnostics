# Odd-only finite-window global prefactor C(p,h)

Date: 2026-06-25

## 1. Scope

This note studies the unpartitioned odd-only finite-window observable

```text
N = 2^p
bit_length(n) = p-h
R(p,h) = P(the odd Syracuse orbit exceeds N)
Q(p,h) = 2^h R(p,h).
```

The residue law has already separated the low-bit dependence:

```text
Q_r(p,h;2^s) approximately Q(p,h) A_r(s-1).
```

The remaining common factor is therefore

```text
C(p,h) approximately Q(p,h),
```

viewed here as a global first-passage prefactor.

This is a finite-window analysis, not a Collatz proof or an asymptotic theorem.

## 2. Q(p,h) table

The table was extracted from the saved odd-only status arrays. No new large exhaustive run was required.

| p \ h | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 18 | 0.603989 | 0.626343 | 0.613037 | 0.586914 | 0.593750 | 0.609375 | 0.750000 | 0.750000 | 0 | 0 | 0 |
| 20 | 0.602757 | 0.623993 | 0.607788 | 0.592285 | 0.562500 | 0.562500 | 0.531250 | 0.562500 | 0 | 0 | 0 |
| 22 | 0.603359 | 0.624908 | 0.613647 | 0.597595 | 0.572021 | 0.492188 | 0.347656 | 0.265625 | 0.125000 | 0 | 0 |
| 24 | 0.604251 | 0.627749 | 0.621559 | 0.615204 | 0.605225 | 0.597656 | 0.580078 | 0.500000 | 0.343750 | 0.187500 | 0 |
| 26 | 0.604241 | 0.627713 | 0.621515 | 0.614414 | 0.606781 | 0.586731 | 0.565918 | 0.547852 | 0.488281 | 0.328125 | 0.125000 |
| 28 | 0.604535 | 0.628727 | 0.623922 | 0.619671 | 0.618523 | 0.614456 | 0.607910 | 0.594971 | 0.619141 | 0.621094 | 0.562500 |

Every CSV row also contains the layer size, escape count, and binomial standard error.

## 3. Shape in the h direction

### h=0

`Q(p,0)` is exceptionally stable:

```text
0.60276 to 0.60453 for p=18..28.
```

However, `h=0` is the top bit layer `[N/2,N)`, not an interior rare-escape regime. Its stable value near 0.604 should not automatically be identified with an asymptotic tail constant.

### h=1

`Q(p,1)` is also stable and slightly higher:

```text
0.62399 to 0.62873 for p=20..28.
```

The residue-level analysis showed clipping of the most expansion-heavy classes here. Thus the unpartitioned value is stable, but it mixes linear-tail behavior with a near-boundary saturation effect.

### Interior h=2..6

At `p=28`:

```text
h=2  0.623922
h=3  0.619671
h=4  0.618523
h=5  0.614456
h=6  0.607910
```

This is a narrow band around 0.61-0.62, with a mild downward slope of approximately `-0.00372` per h.

The range over `h=2..6` shrinks from noisy small-p values to only `0.0160` at `p=28`. Thus the interior is becoming flatter, but the available data do not prove that all fixed h converge to one constant.

### Large h

Large h means a much smaller starting layer and a much rarer escape event. The resulting Q values become quantized and noisy.

Examples:

- `p=18,h>=8`: no observed escapes;
- `p=24,h=10`: no observed escapes;
- `p=28,h=10`: only a small tail count, giving `Q=0.5625`.

The rebounds at `p=28,h=8,9` should therefore not be read as a resolved oscillation without larger samples.

## 4. Shape in the p direction

For fixed `h=2..6`, two simple models were compared:

```text
constant: Q(p,h) = C
inverse-p: Q(p,h) = C + a/p.
```

Because `log2 N=p`, the proposed `1/log2 N` correction is exactly the same model as `1/p`.

### Fit summary

| h | constant mean, all even p | C from 1/p, all even p | C from 1/p, p=24..28 | mean at p=24,26,28 |
|---:|---:|---:|---:|---:|
| 2 | 0.61691 | 0.64904 | 0.63722 | 0.62233 |
| 3 | 0.60435 | 0.68385 | 0.64435 | 0.61643 |
| 4 | 0.59313 | 0.67746 | 0.69458 | 0.61018 |
| 5 | 0.57715 | 0.61743 | 0.70197 | 0.59961 |
| 6 | 0.56380 | 0.36545 | 0.75551 | 0.58464 |

The free `C+a/p` intercept is unstable: it changes strongly with h and with the fitting window, and becomes nonsensical when sparse low-p tail values are included.

Therefore the present data do **not** identify an asymptotic C by free extrapolation. The `1/p` fit can reduce in-window residuals for h=2 or 3, but its extrapolated intercept is not robust.

The most defensible numerical statement is:

> for the largest measured window, the well-sampled interior values lie near 0.61-0.624 and move toward the same band as p increases.

## 5. Log-periodic diagnostic

Existing odd-power data for `p=19,21,23,25,27` were combined with the even-power table, giving consecutive `p=18..28`.

As the simplest log-periodic diagnostic, a parity term was added:

```text
Q(p,h) = C + a/p + b(-1)^p.
```

For `h=2..5`:

```text
|b| <= 0.00057
parity term changes RMSE by less than about 0.1%.
```

No period-two log oscillation is visible in the well-sampled range.

At `h=6`, the fitted parity amplitude is about `-0.013`, but the same cells contain strong sampling noise and sparse escapes, so this is not persuasive evidence.

Eleven consecutive powers are insufficient for a broad search over arbitrary log periods. The result only says that the simplest even/odd oscillation is unsupported.

## 6. Iid Syracuse random-walk candidate

Consider the iid approximation

```text
X_i = log2(3) - k_i
P(k_i=j) = 2^(-j),  j>=1
S_n = X_1 + ... + X_n.
```

The mean drift is negative:

```text
E[X] = log2(3) - 2
     approximately -0.4150375.
```

Escape from log-distance D is modeled by

```text
P(sup_n S_n > D).
```

### Cramer exponent

The exponent-one root is exact in this model:

```text
E[2^X]
  = E[3 / 2^k]
  = 1.
```

Thus renewal theory predicts

```text
P(sup_n S_n > D)
  approximately c_RW(D) 2^(-D),
```

with an overshoot prefactor.

### Exponential tilt and overshoot

At the root, the tilted valuation law is

```text
q(k)
  = P(k) 2^(log2(3)-k)
  = 3 / 4^k.
```

Its drift is positive:

```text
E_q[X]
  = log2(3) - 4/3
  approximately 0.25163.
```

If `O_D=S_tau-D` is the overshoot under the tilted walk, change of measure gives

```text
c_RW(D) = E_q[2^(-O_D)].
```

Importance-sampling with 100,000 paths gave exact-barrier values around

```text
c_RW(D) approximately 0.832 to 0.839.
```

This is not yet the measured bit-layer prefactor.

## 7. Why bit-layer averaging brings 0.833 down to about 0.624

A bit-length layer is not concentrated at log-distance exactly h. Write

```text
n = 2^(p-h) y,
1/2 <= y < 1.
```

Then

```text
D = log2(N/n) = h - log2(y).
```

Odd integers are uniformly distributed across this interval, and their normalized mean is exactly

```text
E[y] = 3/4.
```

If the overshoot factor varies slowly across one bit,

```text
Q(p,h)
  = 2^h E[P(escape | y)]
  approximately E[y c_RW(h-log2 y)]
  approximately (3/4)c_RW.
```

The direct layer-averaged importance-sampling estimates were:

| nominal h | exact-barrier c_RW | layer-averaged C_RW |
|---:|---:|---:|
| 5 | 0.83941 | 0.62414 |
| 10 | 0.83163 | 0.62337 |
| 20 | 0.83612 | 0.62337 |
| 40 | 0.83194 | 0.62370 |

The layer average is remarkably stable:

```text
C_RW,layer approximately 0.6234 to 0.6241.
```

This agrees closely with:

- `Q(28,2)=0.623922`;
- the high-p h=2 values;
- the upper part of the measured interior band.

Thus a plausible candidate explanation for the common scale is:

> exponent one comes from `E[3/2^k]=1`; the numerical prefactor is an iid first-passage overshoot constant, averaged across the one-bit starting layer.

This is substantially more informative than treating 0.61 as an unexplained fitted number.

## 8. Why this is not yet a derivation for the actual Collatz map

The random-walk calculation assumes iid geometric valuations along the orbit. For random 2-adic inputs this is the natural local model, but the actual deterministic finite-window problem can retain:

- correlations along integer trajectories;
- first-passage conditioning;
- finite-p truncation;
- affine `+1` effects;
- dependence between visiting the upper tail and later valuation words.

The measured decrease from `Q(28,2)=0.6239` to `Q(28,6)=0.6079` is larger than binomial noise and is not explained by one universal finite-p iid constant.

Therefore:

- the iid overshoot model explains the scale `approximately 0.624` and exponent one;
- it does not yet derive all observed `p,h` corrections;
- agreement at one or several cells is evidence, not proof of mechanism.

## 9. Two-stage finite-window decomposition

The combined empirical model is

```text
Q_r(p,h;2^s)
  approximately C(p,h) A_r(s-1).
```

The two factors have distinct roles:

```text
A_r(s-1):
  local low-bit scale multiplier;
  explains residue splitting.

C(p,h) approximately Q(p,h):
  global finite-window first-passage prefactor;
  approximately 0.61-0.624 in the resolved interior;
  candidate iid layer-averaged overshoot value approximately 0.6236.
```

A compact interpretation is:

> residue differences come from the finite 2-adic prefix; the common scale comes from the global first-passage problem after averaging over the one-bit starting layer.

## 10. Current boundary between result and open problem

Supported by exact finite enumeration:

- Q is near 0.61-0.624 in the largest well-sampled interior layers;
- h=0 and h=1 have stable but boundary-specific values;
- large-h failures track sparse escape counts;
- no simple period-two log oscillation is detected;
- the residue/global two-factor decomposition remains consistent.

Supported by the iid model:

- the exponent is one;
- a layer-averaged overshoot prefactor near 0.6235 is natural.

Still open:

- whether fixed-h Q(p,h) converges as p tends to infinity;
- whether all interior h share one limit;
- the correct finite-p correction law;
- whether the actual deterministic overshoot constant equals the iid value;
- a rigorous renewal description for the odd-only Collatz finite-window observable.

The number 0.61 should therefore be treated as a finite-window empirical band, with `approximately 0.6235` as a motivated iid overshoot candidate, not as an established universal constant.

