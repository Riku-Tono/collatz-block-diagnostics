# Collatz Trajectory Geometry Sampled

This sampled run compares raw growth `X(u)`, normalized shape `Y(u)`, and bridge residual `Z(u)=X_i-uX_tau`.

The full all-escape version was stopped as too heavy; this version uses previously generated sampled CSVs.

| group | actual mass | iid mass | mean abs delta Z | max abs delta Z |
|---|---:|---:|---:|---:|
| h=6|tau=long | 0.0132904 | 0.00311859 | 0.0978781 | 0.238539 |
| h=4|tau=long | 0.0611118 | 0.012694 | 0.0599202 | 0.0939736 |
| h=5|tau=long | 0.027788 | 0.00612517 | 0.0557095 | 0.117803 |
| h=6 | 0.0468426 | 0.00975333 | 0.0540499 | 0.100353 |
| h=5 | 0.0949121 | 0.0195167 | 0.0357695 | 0.0530671 |
| long_tau | 0.473231 | 0.097022 | 0.0354739 | 0.0586653 |
| tau=long | 0.473231 | 0.097022 | 0.0354739 | 0.0586653 |
| h=3|tau=long | 0.118864 | 0.023968 | 0.0324243 | 0.0626733 |
| h=4 | 0.192477 | 0.039004 | 0.0275497 | 0.0370307 |
| h=2|tau=long | 0.252176 | 0.0511163 | 0.0249876 | 0.0392468 |
| h=6|tau=middle | 0.01546 | 0.0030875 | 0.0227199 | 0.0609278 |
| overall | 1.50035 | 0.302259 | 0.0169865 | 0.0233215 |
| h=2 | 0.779289 | 0.156224 | 0.0117665 | 0.0179375 |
| h=3 | 0.386827 | 0.0777602 | 0.0116205 | 0.022191 |
| h=5|tau=middle | 0.034116 | 0.00679926 | 0.0105187 | 0.0308939 |
| h=6|tau=short | 0.0180922 | 0.00354724 | 0.00905573 | 0.0308252 |
| h=4|tau=middle | 0.0630175 | 0.0126968 | 0.00361562 | 0.0095449 |
| h=5|tau=short | 0.033008 | 0.00659231 | 0.00283398 | 0.00957251 |
| h=2|tau=middle | 0.210106 | 0.0421217 | 0.00250781 | 0.00585142 |
| tau=middle | 0.441642 | 0.0888267 | 0.00214189 | 0.0064749 |

Outputs:

- `collatz_trajectory_sampled_profiles.csv`
- `collatz_trajectory_sampled_differences.csv`
- `collatz_trajectory_sampled_group_metrics.csv`
- `collatz_trajectory_sampled_delta_X.svg`
- `collatz_trajectory_sampled_delta_Y.svg`
- `collatz_trajectory_sampled_delta_Z.svg`
- `collatz_trajectory_sampled_long_parity_delta_Z.svg`