# Collatz Cumulative Tail Survival

Definition:

```text
S_tail,p(x,h) = actual mass with K_tau-(p-h) >= x
                / iid mass with K_tau-(p-h) >= x
```

This is the cumulative version of the survival operator. It should be compared with the pointwise `S_p(K,h)` table.

| x cut | tail S collapsed | actual tail mass | iid tail mass |
|---:|---:|---:|---:|
| -4 | 0.978846 | 0.52002662 | 0.5312648 |
| -3 | 0.977526 | 0.48412335 | 0.49525381 |
| -2 | 0.976109 | 0.45442611 | 0.46554857 |
| -1 | 0.974455 | 0.42284232 | 0.43392718 |
| 0 | 0.972695 | 0.39730597 | 0.40845911 |
| 1 | 0.971246 | 0.37366396 | 0.38472652 |
| 2 | 0.969442 | 0.34836507 | 0.35934607 |
| 3 | 0.967949 | 0.32850778 | 0.33938536 |
| 4 | 0.965552 | 0.30896205 | 0.31998497 |
| 5 | 0.963151 | 0.28833294 | 0.29936434 |
| 6 | 0.960783 | 0.27151215 | 0.28259456 |
| 7 | 0.958153 | 0.25412112 | 0.2652198 |
| 8 | 0.955388 | 0.2385754 | 0.24971581 |
| 9 | 0.951992 | 0.22454613 | 0.23586984 |
| 10 | 0.948559 | 0.20957547 | 0.22094092 |
| 11 | 0.945864 | 0.19801176 | 0.20934475 |
| 12 | 0.942584 | 0.1866917 | 0.19806369 |

Interpretation: the pointwise ratio is close to 1 near the boundary, while the cumulative tail ratio carries the exhausted-region deficit. This means the earlier localization is a tail-mass statement, not a sharp pointwise survival drop at a single K.