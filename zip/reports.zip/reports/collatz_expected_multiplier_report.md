# Collatz residue prefactor: expected-multiplier test

Date: 2026-06-25

## Question

For the odd-only observable at `p=26, h=3`, test whether the residue-class prefactor `Q_r` is predicted by the finite-depth Syracuse multiplier

```text
A_r(d) = E[3^d / 2^K_d | n ≡ r (mod 2^s)]
K_d = k_1 + ... + k_d
k_i = v2(3n_i + 1)
```

The expectation was computed by enumerating 2-adic lifts. No new reach/escape status table was generated, so this test is light compared with the previous exhaustive run.

## Main result

The hypothesis works extremely well.

### mod 32

```text
depth  corr(log A, log Q)   R^2       LOOCV RMSE in log2(Q)
1      0.688911             0.47460   1.304100
2      0.903928             0.81709   0.801189
3      0.984443             0.96913   0.368295
4      0.999888             0.99978   0.031192
5      0.999888             0.99978   0.031192
6      0.999888             0.99978   0.031191
```

The improvement saturates at depth 4.

### mod 64

```text
depth  corr(log A, log Q)   R^2       LOOCV RMSE in log2(Q)
1      0.630006             0.39691   1.498538
2      0.849433             0.72154   1.028332
3      0.956022             0.91398   0.589567
4      0.993367             0.98678   0.246305
5      0.999632             0.99926   0.057628
6      0.999632             0.99926   0.057627
7      0.999632             0.99926   0.057628
8      0.999632             0.99926   0.057627
```

The improvement saturates at depth 5.

This supports the pattern:

```text
mod 2^s  ->  required prefix depth approximately s - 1
mod 32   ->  depth 4
mod 64   ->  depth 5
```

## The 31 vs 63 mod 64 residual

At depth 4, both classes have the same multiplier:

```text
A_31(4) = A_63(4) = (3/2)^4 = 5.0625
```

At depth 5:

```text
A_31(5) = 2.53125
A_63(5) = 7.59375
A_63(5) / A_31(5) = 3
```

Observed:

```text
Q_31 = 1.57117
Q_63 = 4.66724
Q_63 / Q_31 = 2.970
```

Thus the previously unexplained factor near 3 is quantitatively accounted for by the fifth-step expected multiplier.

## Stronger empirical form

For most mod64 classes,

```text
Q_r / A_r(5) ≈ 0.60
```

Across all 32 classes:

```text
median Q/A_5 = 0.60634
mean Q/A_5   = 0.59477
standard deviation = 0.03249
```

The lowest-Q classes have the largest relative finite-sample deviation. The central value is close to the previously measured global odd-only prefactor near `0.61`.

A useful empirical relation is therefore:

```text
Q_r ≈ C * E[3^(s-1) / 2^K_(s-1) | r mod 2^s]
C ≈ 0.60 to 0.61
```

For mod64, the fitted log-log slope is `1.038`, close to the slope 1 predicted by direct proportionality.

## Numerical stability

The mod64 calculation was repeated with lift bit widths 18, 20, and 22. The depth-5 fit and the values

```text
A_31(5) = 2.53125
A_63(5) = 7.59375
```

were stable.

## What is established

For this measured observable and dataset:

- The mod32 hierarchy is predicted almost completely by the depth-4 expected multiplier.
- The mod64 hierarchy is predicted almost completely by the depth-5 expected multiplier.
- The mod64 31-vs-63 residual is resolved at depth 5.
- Increasing depth beyond the first sufficient depth does not materially improve prediction.

## What is not yet established

- This is still calibrated against `p=26, h=3`; independence across `p` and `h` has not yet been tested.
- The relation is an empirical transfer law, not an asymptotic theorem.
- The pattern `mod 2^s -> depth s-1` has only been checked for `s=5,6`.
- The constant `C` has not been derived.

The next meaningful test is out-of-sample validation across several `p,h` values. Mod128 should come after that, not before it.

