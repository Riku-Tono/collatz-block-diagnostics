from __future__ import annotations

import argparse
import csv
import math
import statistics
import time
from pathlib import Path


UNKNOWN = 0
REACH = 1
ESCAPE = 2


def next_odd(n: int) -> int:
    m = 3 * n + 1
    return m >> ((m & -m).bit_length() - 1)


def compute_status(power: int) -> bytearray:
    n_max = 1 << power
    status = bytearray(n_max >> 1)
    status[0] = REACH
    for n in range(3, n_max + 1, 2):
        idx = n >> 1
        if status[idx] != UNKNOWN:
            continue
        path: list[int] = []
        cur = n
        while True:
            if cur > n_max:
                result = ESCAPE
                break
            cur_idx = cur >> 1
            known = status[cur_idx]
            if known != UNKNOWN:
                result = known
                break
            path.append(cur_idx)
            cur = next_odd(cur)
        for path_idx in path:
            status[path_idx] = result
    return status


def load_or_compute_status(power: int, cache_dir: Path) -> bytearray:
    cache_dir.mkdir(parents=True, exist_ok=True)
    path = cache_dir / f"odd_only_status_p{power}.bin"
    expected_size = 1 << (power - 1)
    if path.exists() and path.stat().st_size == expected_size:
        print(f"p={power}: loading status cache {path}", flush=True)
        return bytearray(path.read_bytes())
    print(f"p={power}: computing {expected_size:,} odd statuses", flush=True)
    started = time.perf_counter()
    status = compute_status(power)
    path.write_bytes(status)
    print(f"p={power}: status ready in {time.perf_counter() - started:.1f}s", flush=True)
    return status


def aggregate_power(power: int, hs: list[int], status: bytearray) -> list[dict[str, int | float | str]]:
    rows: list[dict[str, int | float | str]] = []
    for h in hs:
        bit_length = power - h
        lo = (1 << (bit_length - 1)) + 1
        hi = (1 << bit_length) - 1
        totals64 = [0] * 64
        reached64 = [0] * 64
        for n in range(lo, hi + 1, 2):
            residue = n & 63
            totals64[residue] += 1
            reached64[residue] += status[n >> 1] == REACH

        total_all = sum(totals64)
        reached_all = sum(reached64)
        miss_all = 1.0 - reached_all / total_all
        rows.append(
            {
                "power": power, "h": h, "bit_length": bit_length,
                "modulus": 0, "residue": -1, "total": total_all,
                "reached": reached_all, "miss_rate": miss_all,
                "Q": miss_all * (2**h),
            }
        )

        for modulus in (32, 64):
            for residue in range(1, modulus, 2):
                if modulus == 64:
                    total = totals64[residue]
                    reached = reached64[residue]
                else:
                    total = totals64[residue] + totals64[residue + 32]
                    reached = reached64[residue] + reached64[residue + 32]
                miss = 1.0 - reached / total
                rows.append(
                    {
                        "power": power, "h": h, "bit_length": bit_length,
                        "modulus": modulus, "residue": residue, "total": total,
                        "reached": reached, "miss_rate": miss,
                        "Q": miss * (2**h),
                    }
                )
        print(f"p={power}, h={h}: aggregated {total_all:,} starts", flush=True)
    return rows


def write_rows(path: Path, rows: list[dict[str, int | float | str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def rank(values: list[float]) -> list[float]:
    order = sorted(range(len(values)), key=values.__getitem__)
    result = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and values[order[j]] == values[order[i]]:
            j += 1
        average_rank = (i + j - 1) / 2 + 1
        for index in order[i:j]:
            result[index] = average_rank
        i = j
    return result


def pearson(xs: list[float], ys: list[float]) -> float:
    xb = sum(xs) / len(xs)
    yb = sum(ys) / len(ys)
    num = sum((x - xb) * (y - yb) for x, y in zip(xs, ys))
    den = math.sqrt(sum((x - xb) ** 2 for x in xs) * sum((y - yb) ** 2 for y in ys))
    return num / den if den else float("nan")


def fit(xs: list[float], ys: list[float]) -> tuple[float, float, float, float]:
    xb = sum(xs) / len(xs)
    yb = sum(ys) / len(ys)
    ssx = sum((x - xb) ** 2 for x in xs)
    beta = sum((x - xb) * (y - yb) for x, y in zip(xs, ys)) / ssx
    alpha = yb - beta * xb
    predictions = [alpha + beta * x for x in xs]
    sse = sum((y - prediction) ** 2 for y, prediction in zip(ys, predictions))
    sst = sum((y - yb) ** 2 for y in ys)
    r2 = 1.0 - sse / sst if sst else float("nan")
    rmse = math.sqrt(sse / len(xs))
    return alpha, beta, r2, rmse


def load_multiplier(path: Path, depth: int) -> dict[int, float]:
    result: dict[int, float] = {}
    for row in read_rows(path):
        if int(row["depth"]) == depth:
            result[int(row["residue"])] = float(row["expected_multiplier"])
    return result


def classify(
    zero_classes: int, min_samples: int, r2: float, slope: float,
    spearman_fraction: float, min_misses: int, saturation_classes: int,
    power: int
) -> str:
    reasons = []
    if zero_classes:
        reasons.append("zero-Q classes")
    if min_samples < 500:
        reasons.append("small per-residue sample")
    if min_misses < 5:
        reasons.append("sparse escape counts")
    if saturation_classes:
        reasons.append("near-boundary saturation")
    if not math.isnan(r2) and r2 < 0.99:
        reasons.append("R2 below 0.99")
    if not math.isnan(slope) and abs(slope - 1.0) > 0.15:
        reasons.append("slope far from 1")
    if not math.isnan(spearman_fraction) and spearman_fraction < 0.98:
        reasons.append("group-rank instability")
    if power <= 20 and reasons:
        reasons.append("small p")
    return "pass" if not reasons else "; ".join(reasons)


def build_metrics(
    raw_rows: list[dict[str, str]], multiplier_paths: dict[int, tuple[Path, int]]
) -> list[dict[str, int | float | str]]:
    multipliers = {
        modulus: load_multiplier(path, depth)
        for modulus, (path, depth) in multiplier_paths.items()
    }
    groups: dict[tuple[int, int, int], list[dict[str, str]]] = {}
    overall_q: dict[tuple[int, int], float] = {}
    for row in raw_rows:
        power = int(row["power"])
        h = int(row["h"])
        modulus = int(row["modulus"])
        if modulus == 0:
            overall_q[(power, h)] = float(row["Q"])
        else:
            groups.setdefault((power, h, modulus), []).append(row)

    metrics = []
    for (power, h, modulus), rows in sorted(groups.items()):
        rows.sort(key=lambda row: int(row["residue"]))
        a_values = [multipliers[modulus][int(row["residue"])] for row in rows]
        q_values = [float(row["Q"]) for row in rows]
        ratios = [q / a for q, a in zip(q_values, a_values)]
        positive = [(a, q) for a, q in zip(a_values, q_values) if q > 0.0]
        zero_classes = len(rows) - len(positive)
        if len(positive) >= 3:
            xs = [math.log2(a) for a, _ in positive]
            ys = [math.log2(q) for _, q in positive]
            correlation = pearson(xs, ys)
            intercept, slope, r2, rmse = fit(xs, ys)
        else:
            correlation = intercept = slope = r2 = rmse = float("nan")
        # Theoretical A values form exact discrete levels. Lift enumeration leaves
        # tiny floating-point differences inside a level, so restore those ties
        # before computing rank preservation.
        rounded_a = [round(a, 7) for a in a_values]
        spearman = pearson(rank(rounded_a), rank(q_values))
        ideal_order = sorted(range(len(rounded_a)), key=rounded_a.__getitem__)
        ideal_q_ranks = [0.0] * len(rounded_a)
        for position, index in enumerate(ideal_order, start=1):
            ideal_q_ranks[index] = float(position)
        spearman_ceiling = pearson(rank(rounded_a), ideal_q_ranks)
        spearman_fraction = min(1.0, spearman / spearman_ceiling)
        ratio_mean = sum(ratios) / len(ratios)
        ratio_std = math.sqrt(sum((ratio - ratio_mean) ** 2 for ratio in ratios) / len(ratios))
        min_samples = min(int(row["total"]) for row in rows)
        min_misses = min(int(row["total"]) - int(row["reached"]) for row in rows)
        saturation_classes = sum(
            overall_q[(power, h)] * a > 2**h for a in a_values
        )
        status = classify(
            zero_classes, min_samples, r2, slope, spearman_fraction,
            min_misses, saturation_classes, power
        )
        metrics.append(
            {
                "role": "discovery" if power == 26 and h == 3 else "validation",
                "power": power, "h": h, "modulus": modulus,
                "depth": multiplier_paths[modulus][1],
                "classes": len(rows), "positive_Q_classes": len(positive),
                "zero_Q_classes": zero_classes, "min_samples_per_residue": min_samples,
                "corr_logA_logQ": correlation, "R2": r2,
                "fitted_slope": slope, "intercept_log2": intercept,
                "RMSE_log2Q": rmse, "spearman_rank": spearman,
                "spearman_tie_ceiling": spearman_ceiling,
                "spearman_fraction_of_ceiling": spearman_fraction,
                "median_Q_over_A": statistics.median(ratios),
                "mean_Q_over_A": ratio_mean, "std_Q_over_A": ratio_std,
                "overall_Q": overall_q[(power, h)],
                "median_C_minus_overall_Q": statistics.median(ratios) - overall_q[(power, h)],
                "min_misses_per_residue": min_misses,
                "near_boundary_saturation_classes": saturation_classes,
                "classification": status,
            }
        )
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--powers", nargs="+", type=int, default=[20, 22, 24, 26, 28])
    parser.add_argument("--hs", nargs="+", type=int, default=[1, 2, 3, 4, 5, 6])
    parser.add_argument("--cache-dir", type=Path, default=Path("work/status_cache"))
    parser.add_argument("--out-dir", type=Path, default=Path("outputs"))
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    all_raw: list[dict[str, str]] = []
    for power in args.powers:
        power_path = args.out_dir / f"collatz_oos_q_p{power}.csv"
        if args.resume and power_path.exists():
            print(f"p={power}: reusing {power_path}", flush=True)
        else:
            status = load_or_compute_status(power, args.cache_dir)
            rows = aggregate_power(power, args.hs, status)
            write_rows(power_path, rows)
            del status
        all_raw.extend(read_rows(power_path))

    combined_path = args.out_dir / "collatz_oos_residue_q.csv"
    with combined_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(all_raw[0]))
        writer.writeheader()
        writer.writerows(all_raw)

    metrics = build_metrics(
        all_raw,
        {
            32: (args.out_dir / "collatz_mod32_expected_multiplier.csv", 4),
            64: (args.out_dir / "collatz_mod64_expected_multiplier.csv", 5),
        },
    )
    metrics_path = args.out_dir / "collatz_oos_metrics.csv"
    write_rows(metrics_path, metrics)

    print("\np h mod role       R2       slope    rank/ceil medianC  overallQ classification")
    for row in metrics:
        print(
            f"{int(row['power']):2d} {int(row['h']):1d} {int(row['modulus']):3d} "
            f"{str(row['role']):10s} {float(row['R2']):8.5f} "
            f"{float(row['fitted_slope']):8.4f} {float(row['spearman_fraction_of_ceiling']):8.5f} "
            f"{float(row['median_Q_over_A']):7.4f} {float(row['overall_Q']):8.5f} "
            f"{row['classification']}"
        )


if __name__ == "__main__":
    main()
