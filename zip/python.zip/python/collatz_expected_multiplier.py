from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path


def v2(n: int) -> int:
    return (n & -n).bit_length() - 1


def pearson(xs: list[float], ys: list[float]) -> float:
    xb = sum(xs) / len(xs)
    yb = sum(ys) / len(ys)
    num = sum((x - xb) * (y - yb) for x, y in zip(xs, ys))
    den = math.sqrt(
        sum((x - xb) ** 2 for x in xs) * sum((y - yb) ** 2 for y in ys)
    )
    return num / den if den else float("nan")


def linear_fit(xs: list[float], ys: list[float]) -> tuple[float, float, float, float]:
    xb = sum(xs) / len(xs)
    yb = sum(ys) / len(ys)
    ssx = sum((x - xb) ** 2 for x in xs)
    beta = sum((x - xb) * (y - yb) for x, y in zip(xs, ys)) / ssx
    alpha = yb - beta * xb
    fitted = [alpha + beta * x for x in xs]
    sse = sum((y - yhat) ** 2 for y, yhat in zip(ys, fitted))
    sst = sum((y - yb) ** 2 for y in ys)
    r2 = 1.0 - sse / sst
    rmse = math.sqrt(sse / len(xs))
    return alpha, beta, r2, rmse


def loocv_rmse(xs: list[float], ys: list[float]) -> float:
    errors = []
    for held_out in range(len(xs)):
        train_x = [x for i, x in enumerate(xs) if i != held_out]
        train_y = [y for i, y in enumerate(ys) if i != held_out]
        alpha, beta, _, _ = linear_fit(train_x, train_y)
        errors.append(ys[held_out] - (alpha + beta * xs[held_out]))
    return math.sqrt(sum(error * error for error in errors) / len(errors))


def read_q(path: Path) -> dict[int, float]:
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return {int(row["residue"]): float(row["Q"]) for row in csv.DictReader(f)}


def calculate(modulus: int, lift_bits: int, max_depth: int) -> list[dict[str, float | int]]:
    residues = tuple(range(1, modulus, 2))
    counts = {residue: 0 for residue in residues}
    sum_multiplier = {
        depth: {residue: 0.0 for residue in residues}
        for depth in range(1, max_depth + 1)
    }
    sum_multiplier_sq = {
        depth: {residue: 0.0 for residue in residues}
        for depth in range(1, max_depth + 1)
    }
    growth_counts = {
        depth: {residue: 0 for residue in residues}
        for depth in range(1, max_depth + 1)
    }
    k_sum_counts = {
        depth: {residue: {} for residue in residues}
        for depth in range(1, max_depth + 1)
    }

    for n in range(1, 1 << lift_bits, 2):
        residue = n % modulus
        counts[residue] += 1
        cur = n
        cumulative_k = 0
        for depth in range(1, max_depth + 1):
            raw = 3 * cur + 1
            k = v2(raw)
            cur = raw >> k
            cumulative_k += k
            multiplier = (3**depth) / (2**cumulative_k)
            sum_multiplier[depth][residue] += multiplier
            sum_multiplier_sq[depth][residue] += multiplier * multiplier
            growth_counts[depth][residue] += int(multiplier > 1.0)
            distribution = k_sum_counts[depth][residue]
            distribution[cumulative_k] = distribution.get(cumulative_k, 0) + 1

    rows: list[dict[str, float | int]] = []
    for residue in residues:
        count = counts[residue]
        for depth in range(1, max_depth + 1):
            mean = sum_multiplier[depth][residue] / count
            variance = sum_multiplier_sq[depth][residue] / count - mean * mean
            distribution = k_sum_counts[depth][residue]
            rows.append(
                {
                    "modulus": modulus,
                    "lift_bits": lift_bits,
                    "lifts_per_residue": count,
                    "residue": residue,
                    "depth": depth,
                    "expected_multiplier": mean,
                    "variance_multiplier": max(0.0, variance),
                    "probability_multiplier_gt_1": growth_counts[depth][residue] / count,
                    "K_distribution": ";".join(
                        f"{k}:{distribution[k] / count:.10f}" for k in sorted(distribution)
                    ),
                }
            )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--modulus", type=int, default=64)
    parser.add_argument("--lift-bits", type=int, default=20)
    parser.add_argument("--max-depth", type=int, default=8)
    parser.add_argument(
        "--q-file", type=Path, default=Path("outputs/collatz_mod64_features.csv")
    )
    parser.add_argument("--out-dir", type=Path, default=Path("outputs"))
    args = parser.parse_args()

    if args.modulus & (args.modulus - 1):
        raise ValueError("modulus must be a power of two")
    if args.lift_bits <= int(math.log2(args.modulus)):
        raise ValueError("lift-bits must exceed log2(modulus)")

    rows = calculate(args.modulus, args.lift_bits, args.max_depth)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    features_path = args.out_dir / f"collatz_mod{args.modulus}_expected_multiplier.csv"
    with features_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    q_by_residue = read_q(args.q_file)
    fit_rows = []
    for depth in range(1, args.max_depth + 1):
        depth_rows = [row for row in rows if int(row["depth"]) == depth]
        xs = [math.log2(float(row["expected_multiplier"])) for row in depth_rows]
        ys = [math.log2(q_by_residue[int(row["residue"])]) for row in depth_rows]
        alpha, beta, r2, rmse = linear_fit(xs, ys)
        fit_rows.append(
            {
                "depth": depth,
                "pearson_logA_logQ": pearson(xs, ys),
                "alpha": alpha,
                "beta": beta,
                "R2": r2,
                "in_sample_RMSE_log2Q": rmse,
                "LOOCV_RMSE_log2Q": loocv_rmse(xs, ys),
            }
        )

    fit_path = args.out_dir / f"collatz_mod{args.modulus}_expected_multiplier_fits.csv"
    with fit_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(fit_rows[0]))
        writer.writeheader()
        writer.writerows(fit_rows)

    print("depth  corr(logA,logQ)  beta     R2       LOOCV_RMSE")
    for row in fit_rows:
        print(
            f"{int(row['depth']):5d}  {float(row['pearson_logA_logQ']):16.6f}  "
            f"{float(row['beta']):7.4f}  {float(row['R2']):7.5f}  "
            f"{float(row['LOOCV_RMSE_log2Q']):11.6f}"
        )

    for residue in (31, 63):
        print(f"\nresidue {residue}")
        for row in rows:
            if int(row["residue"]) == residue:
                print(
                    f"d={int(row['depth'])}: "
                    f"E[M]={float(row['expected_multiplier']):.9f}, "
                    f"P(M>1)={float(row['probability_multiplier_gt_1']):.6f}"
                )


if __name__ == "__main__":
    main()
