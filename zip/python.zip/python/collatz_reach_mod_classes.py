from __future__ import annotations

import argparse
from collections import defaultdict

from collatz_reach_cliff import REACH, compute_status


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--power", type=int, default=26)
    parser.add_argument("--mod", type=int, default=8)
    parser.add_argument("--h-max", type=int, default=8)
    args = parser.parse_args()

    n_max = 1 << args.power
    status = compute_status(args.power)

    print(f"definition: odd Syracuse orbit reaches 1 without odd node exceeding N=2^{args.power}")
    print(f"classes mod {args.mod}")
    for h in range(0, args.h_max + 1):
        bit_length = args.power - h
        lo = 1 << (bit_length - 1)
        hi = min((1 << bit_length) - 1, n_max)
        if lo % 2 == 0:
            lo += 1

        totals = defaultdict(int)
        reached = defaultdict(int)
        for n in range(lo, hi + 1, 2):
            r = n % args.mod
            totals[r] += 1
            if status[n >> 1] == REACH:
                reached[r] += 1

        print(f"\nh={h} bit_length={bit_length}")
        print("residue  total    reach       R_miss      Q=R*2^h")
        for r in sorted(totals):
            total = totals[r]
            reach = reached[r] / total
            miss = 1.0 - reach
            print(f"{r:7d} {total:7d}  {reach:.6f}  {miss:.6f}  {miss * (2**h):.6f}")


if __name__ == "__main__":
    main()
