from __future__ import annotations

import argparse
import csv
import time
from pathlib import Path

from collatz_boundary_compare import compute_status_full_peak
from collatz_reach_cliff import REACH, compute_status


def layer_bounds(power: int, h: int) -> tuple[int, int]:
    bit_length = power - h
    lo = 1 << (bit_length - 1)
    hi = (1 << bit_length) - 1
    if lo % 2 == 0:
        lo += 1
    return lo, hi


def aggregate_layer(
    power: int, h: int, status: bytearray, modulus: int
) -> list[dict[str, int | float | str]]:
    lo, hi = layer_bounds(power, h)
    totals = [0] * modulus
    reached = [0] * modulus

    for n in range(lo, hi + 1, 2):
        residue = n % modulus
        totals[residue] += 1
        if status[n >> 1] == REACH:
            reached[residue] += 1

    rows: list[dict[str, int | float | str]] = []
    for residue in range(1, modulus, 2):
        total = totals[residue]
        if total == 0:
            continue
        reach = reached[residue] / total
        miss = 1.0 - reach
        rows.append(
            {
                "N_power": power,
                "N": 1 << power,
                "bit_length": power - h,
                "h": h,
                "modulus": modulus,
                "residue": residue,
                "total": total,
                "reached": reached[residue],
                "reach": reach,
                "R_miss": miss,
                "Q_R_times_2h": miss * (2**h),
            }
        )
    return rows


def aggregate_all(power: int, h: int, status: bytearray) -> dict[str, int | float | str]:
    lo, hi = layer_bounds(power, h)
    total = 0
    reached = 0
    for n in range(lo, hi + 1, 2):
        total += 1
        if status[n >> 1] == REACH:
            reached += 1
    reach = reached / total
    miss = 1.0 - reach
    return {
        "N_power": power,
        "N": 1 << power,
        "bit_length": power - h,
        "h": h,
        "modulus": "all",
        "residue": "all",
        "total": total,
        "reached": reached,
        "reach": reach,
        "R_miss": miss,
        "Q_R_times_2h": miss * (2**h),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--powers", nargs="+", type=int, default=[18, 20, 22, 24, 26])
    parser.add_argument("--h-max", type=int, default=12)
    parser.add_argument("--moduli", nargs="+", type=int, default=[8, 16, 32])
    parser.add_argument("--boundary", choices=["odd-only", "full-peak"], default="odd-only")
    parser.add_argument("--out", type=Path, default=Path("work/reach_study.csv"))
    args = parser.parse_args()

    rows: list[dict[str, int | float | str]] = []
    for power in args.powers:
        started = time.perf_counter()
        if args.boundary == "odd-only":
            status = compute_status(power)
        else:
            status = compute_status_full_peak(power)
        status_seconds = time.perf_counter() - started

        for h in range(0, min(args.h_max, power - 1) + 1):
            all_row = aggregate_all(power, h, status)
            all_row["boundary"] = args.boundary
            rows.append(all_row)
            for modulus in args.moduli:
                layer_rows = aggregate_layer(power, h, status, modulus)
                for row in layer_rows:
                    row["boundary"] = args.boundary
                rows.extend(layer_rows)

        elapsed = time.perf_counter() - started
        print(
            f"N=2^{power}: status={status_seconds:.2f}s "
            f"total={elapsed:.2f}s rows={len(rows)}"
        )

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {args.out} ({len(rows)} rows)")


if __name__ == "__main__":
    main()
