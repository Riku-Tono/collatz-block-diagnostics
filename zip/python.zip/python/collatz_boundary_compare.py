from __future__ import annotations

import argparse

from collatz_reach_cliff import ESCAPE, REACH, UNKNOWN, compute_status, next_odd


def compute_status_full_peak(power: int) -> bytearray:
    n_max = 1 << power
    status = bytearray(n_max >> 1)
    status[0] = REACH

    for n in range(3, n_max, 2):
        idx = n >> 1
        if status[idx] != UNKNOWN:
            continue

        path: list[int] = []
        cur = n
        while True:
            if cur > n_max or 3 * cur + 1 > n_max:
                result = ESCAPE
                break

            cur_idx = cur >> 1
            cur_status = status[cur_idx]
            if cur_status != UNKNOWN:
                result = cur_status
                break

            path.append(cur_idx)
            cur = next_odd(cur)

        for path_idx in path:
            status[path_idx] = result

    return status


def summarize(power: int, h: int, status: bytearray, modulus: int = 8) -> tuple[float, dict[int, float]]:
    bit_length = power - h
    lo = (1 << (bit_length - 1)) + 1
    hi = (1 << bit_length) - 1

    total = 0
    reached = 0
    totals = {r: 0 for r in range(1, modulus, 2)}
    reached_by_residue = {r: 0 for r in range(1, modulus, 2)}
    for n in range(lo, hi + 1, 2):
        residue = n % modulus
        total += 1
        totals[residue] += 1
        if status[n >> 1] == REACH:
            reached += 1
            reached_by_residue[residue] += 1

    q_all = (1.0 - reached / total) * (2**h)
    q_by_residue = {
        residue: (1.0 - reached_by_residue[residue] / totals[residue]) * (2**h)
        for residue in totals
    }
    return q_all, q_by_residue


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--power", type=int, default=26)
    parser.add_argument("--h-max", type=int, default=5)
    args = parser.parse_args()

    odd_only = compute_status(args.power)
    full_peak = compute_status_full_peak(args.power)

    print("odd-only: escape when an odd Syracuse node exceeds N")
    print("full-peak: escape when an odd node or its raw 3n+1 value exceeds N")
    for h in range(args.h_max + 1):
        odd_q, odd_mod = summarize(args.power, h, odd_only)
        peak_q, peak_mod = summarize(args.power, h, full_peak)
        ratio = peak_q / odd_q if odd_q else float("nan")
        print(f"\nh={h}: odd_Q={odd_q:.6f} full_peak_Q={peak_q:.6f} ratio={ratio:.6f}")
        print("residue  odd_Q     full_peak_Q  ratio")
        for residue in odd_mod:
            class_ratio = peak_mod[residue] / odd_mod[residue] if odd_mod[residue] else float("nan")
            print(
                f"{residue:7d}  {odd_mod[residue]:.6f}  "
                f"{peak_mod[residue]:.6f}  {class_ratio:.6f}"
            )


if __name__ == "__main__":
    main()
