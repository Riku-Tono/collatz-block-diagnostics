from __future__ import annotations

import argparse
import csv
import math
import random
from pathlib import Path


ESCAPE = 2


def v2(n: int) -> int:
    return (n & -n).bit_length() - 1


def write_csv(path: Path, rows: list[dict[str, int | float | str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


class WeightedMoments:
    def __init__(self) -> None:
        self.w = 0.0
        self.wx = 0.0
        self.wx2 = 0.0

    def add(self, x: float, weight: float = 1.0) -> None:
        self.w += weight
        self.wx += weight * x
        self.wx2 += weight * x * x

    @property
    def mean(self) -> float:
        return self.wx / self.w if self.w else float("nan")

    @property
    def variance(self) -> float:
        if not self.w:
            return float("nan")
        return max(0.0, self.wx2 / self.w - self.mean * self.mean)


class WeightedPairs:
    def __init__(self) -> None:
        self.w = 0.0
        self.wx = self.wy = self.wxx = self.wyy = self.wxy = 0.0

    def add(self, x: float, y: float, weight: float = 1.0) -> None:
        self.w += weight
        self.wx += weight * x
        self.wy += weight * y
        self.wxx += weight * x * x
        self.wyy += weight * y * y
        self.wxy += weight * x * y

    @property
    def correlation(self) -> float:
        if not self.w:
            return float("nan")
        mx = self.wx / self.w
        my = self.wy / self.w
        vx = self.wxx / self.w - mx * mx
        vy = self.wyy / self.w - my * my
        cov = self.wxy / self.w - mx * my
        return cov / math.sqrt(vx * vy) if vx > 0 and vy > 0 else float("nan")


def reservoir_escape_indices(
    status: bytearray, start: int, end: int, target: int, rng: random.Random
) -> tuple[list[int], int]:
    reservoir: list[int] = []
    seen = 0
    for idx in range(start, end):
        if status[idx] != ESCAPE:
            continue
        seen += 1
        if len(reservoir) < target:
            reservoir.append(idx)
        else:
            replacement = rng.randrange(seen)
            if replacement < target:
                reservoir[replacement] = idx
    return reservoir, seen


def trace_actual_escape(n: int, n_max: int) -> tuple[list[int], float, float, float, int]:
    cur = n
    ks: list[int] = []
    approximate_log_multiplier = 0.0
    affine_log_correction = 0.0
    while cur <= n_max:
        raw = 3 * cur + 1
        k = v2(raw)
        ks.append(k)
        approximate_log_multiplier += math.log2(3.0) - k
        affine_log_correction += math.log2(1.0 + 1.0 / (3.0 * cur))
        cur = raw >> k
        if len(ks) > 100_000:
            raise RuntimeError("unexpectedly long escape path")
    overshoot = math.log2(cur / n_max)
    exact_log_multiplier = math.log2(cur / n)
    return ks, overshoot, exact_log_multiplier, affine_log_correction, cur


def summarize_actual(
    power: int, h: int, status: bytearray, target: int, prefix_depth: int,
    rng: random.Random
) -> tuple[dict[str, int | float | str], list[dict[str, int | float | str]]]:
    bit_length = power - h
    lo = (1 << (bit_length - 1)) + 1
    hi = (1 << bit_length) - 1
    start = lo >> 1
    end = (hi >> 1) + 1
    indices, escape_count = reservoir_escape_indices(status, start, end, target, rng)
    overshoot = WeightedMoments()
    steps = WeightedMoments()
    final_multiplier = WeightedMoments()
    affine = WeightedMoments()
    lag_pairs = WeightedPairs()
    k_by_position = [WeightedMoments() for _ in range(prefix_depth)]
    k1_by_position = [WeightedMoments() for _ in range(prefix_depth)]

    for idx in indices:
        n = 2 * idx + 1
        ks, over, exact_log_multiplier, affine_correction, _ = trace_actual_escape(n, 1 << power)
        overshoot.add(over)
        steps.add(len(ks))
        final_multiplier.add(2.0 ** exact_log_multiplier)
        affine.add(affine_correction)
        for position, k in enumerate(ks[:prefix_depth]):
            k_by_position[position].add(k)
            k1_by_position[position].add(k == 1)
        for left, right in zip(ks, ks[1:]):
            lag_pairs.add(left, right)

    summary = {
        "model": "actual_collatz_escape_conditioned",
        "power": power,
        "h": h,
        "layer_total": end - start,
        "layer_escape_count": escape_count,
        "sample_paths": len(indices),
        "mean_overshoot_log2": overshoot.mean,
        "sd_overshoot_log2": math.sqrt(overshoot.variance),
        "mean_escape_steps": steps.mean,
        "mean_final_multiplier": final_multiplier.mean,
        "mean_log2_affine_correction": affine.mean,
        "lag1_k_correlation": lag_pairs.correlation,
        "importance_weight_mean": "",
    }
    position_rows = []
    for position in range(prefix_depth):
        position_rows.append(
            {
                "model": "actual_collatz_escape_conditioned",
                "power": power,
                "h": h,
                "position": position + 1,
                "effective_weight": k_by_position[position].w,
                "mean_k": k_by_position[position].mean,
                "probability_k_eq_1": k1_by_position[position].mean,
            }
        )
    return summary, position_rows


def summarize_actual_unconditioned_prefix(
    power: int, h: int, samples: int, prefix_depth: int
) -> tuple[dict[str, int | float | str], list[dict[str, int | float | str]]]:
    bit_length = power - h
    lo = (1 << (bit_length - 1)) + 1
    hi = (1 << bit_length) - 1
    start = lo >> 1
    end = (hi >> 1) + 1
    total = end - start
    k_by_position = [WeightedMoments() for _ in range(prefix_depth)]
    k1_by_position = [WeightedMoments() for _ in range(prefix_depth)]
    lag_pairs = WeightedPairs()
    for sample in range(samples):
        idx = start + ((2 * sample + 1) * total) // (2 * samples)
        cur = 2 * idx + 1
        ks = []
        for position in range(prefix_depth):
            raw = 3 * cur + 1
            k = v2(raw)
            ks.append(k)
            k_by_position[position].add(k)
            k1_by_position[position].add(k == 1)
            cur = raw >> k
        for left, right in zip(ks, ks[1:]):
            lag_pairs.add(left, right)
    summary = {
        "model": "actual_collatz_unconditioned_prefix",
        "power": power,
        "h": h,
        "layer_total": total,
        "layer_escape_count": "",
        "sample_paths": samples,
        "mean_overshoot_log2": "",
        "sd_overshoot_log2": "",
        "mean_escape_steps": "",
        "mean_final_multiplier": "",
        "mean_log2_affine_correction": "",
        "lag1_k_correlation": lag_pairs.correlation,
        "importance_weight_mean": "",
    }
    position_rows = []
    for position in range(prefix_depth):
        position_rows.append(
            {
                "model": "actual_collatz_unconditioned_prefix",
                "power": power,
                "h": h,
                "position": position + 1,
                "effective_weight": k_by_position[position].w,
                "mean_k": k_by_position[position].mean,
                "probability_k_eq_1": k1_by_position[position].mean,
            }
        )
    return summary, position_rows


def tilted_k(rng: random.Random) -> int:
    k = 1
    while rng.random() < 0.25:
        k += 1
    return k


def summarize_iid_conditioned(
    h: int, samples: int, prefix_depth: int, rng: random.Random
) -> tuple[dict[str, int | float | str], list[dict[str, int | float | str]]]:
    log2_3 = math.log2(3.0)
    overshoot = WeightedMoments()
    steps = WeightedMoments()
    final_multiplier = WeightedMoments()
    lag_pairs = WeightedPairs()
    k_by_position = [WeightedMoments() for _ in range(prefix_depth)]
    k1_by_position = [WeightedMoments() for _ in range(prefix_depth)]
    total_weight = 0.0

    for _ in range(samples):
        y = 0.5 + 0.5 * rng.random()
        distance = h - math.log2(y)
        position = 0.0
        ks: list[int] = []
        while position <= distance:
            k = tilted_k(rng)
            ks.append(k)
            position += log2_3 - k
        over = position - distance
        weight = y * (2.0 ** (-over))
        total_weight += weight
        overshoot.add(over, weight)
        steps.add(len(ks), weight)
        final_multiplier.add(2.0 ** position, weight)
        for index, k in enumerate(ks[:prefix_depth]):
            k_by_position[index].add(k, weight)
            k1_by_position[index].add(k == 1, weight)
        for left, right in zip(ks, ks[1:]):
            lag_pairs.add(left, right, weight)

    summary = {
        "model": "iid_random_walk_escape_conditioned",
        "power": "",
        "h": h,
        "layer_total": "",
        "layer_escape_count": "",
        "sample_paths": samples,
        "mean_overshoot_log2": overshoot.mean,
        "sd_overshoot_log2": math.sqrt(overshoot.variance),
        "mean_escape_steps": steps.mean,
        "mean_final_multiplier": final_multiplier.mean,
        "mean_log2_affine_correction": 0.0,
        "lag1_k_correlation": lag_pairs.correlation,
        "importance_weight_mean": total_weight / samples,
    }
    position_rows = []
    for position in range(prefix_depth):
        position_rows.append(
            {
                "model": "iid_random_walk_escape_conditioned",
                "power": "",
                "h": h,
                "position": position + 1,
                "effective_weight": k_by_position[position].w,
                "mean_k": k_by_position[position].mean,
                "probability_k_eq_1": k1_by_position[position].mean,
            }
        )
    return summary, position_rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--power", type=int, default=28)
    parser.add_argument("--hs", nargs="+", type=int, default=[2, 3, 4, 5, 6])
    parser.add_argument("--actual-samples", type=int, default=20_000)
    parser.add_argument("--iid-samples", type=int, default=50_000)
    parser.add_argument("--prefix-depth", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20260625)
    parser.add_argument("--cache", type=Path, default=Path("work/status_cache/odd_only_status_p28.bin"))
    parser.add_argument("--out-dir", type=Path, default=Path("outputs"))
    args = parser.parse_args()

    expected_size = 1 << (args.power - 1)
    if not args.cache.exists() or args.cache.stat().st_size != expected_size:
        raise FileNotFoundError(f"missing status cache: {args.cache}")
    status = bytearray(args.cache.read_bytes())
    rng = random.Random(args.seed)
    summaries = []
    position_rows = []
    for h in args.hs:
        unconditional_summary, unconditional_positions = summarize_actual_unconditioned_prefix(
            args.power, h, args.actual_samples, args.prefix_depth
        )
        actual_summary, actual_positions = summarize_actual(
            args.power, h, status, args.actual_samples, args.prefix_depth, rng
        )
        iid_summary, iid_positions = summarize_iid_conditioned(
            h, args.iid_samples, args.prefix_depth, rng
        )
        summaries.extend([unconditional_summary, actual_summary, iid_summary])
        position_rows.extend(unconditional_positions)
        position_rows.extend(actual_positions)
        position_rows.extend(iid_positions)
        print(
            f"h={h}: actual overshoot={float(actual_summary['mean_overshoot_log2']):.6f}, "
            f"iid={float(iid_summary['mean_overshoot_log2']):.6f}; "
            f"actual steps={float(actual_summary['mean_escape_steps']):.2f}, "
            f"iid={float(iid_summary['mean_escape_steps']):.2f}; "
            f"affine={float(actual_summary['mean_log2_affine_correction']):.3e}"
        )

    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.out_dir / "collatz_escape_path_summary.csv", summaries)
    write_csv(args.out_dir / "collatz_escape_k_by_position.csv", position_rows)


if __name__ == "__main__":
    main()
