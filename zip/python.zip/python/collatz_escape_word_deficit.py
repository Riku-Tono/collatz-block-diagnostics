from __future__ import annotations

import argparse
import csv
import math
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable


UNKNOWN = 0
REACH = 1
ESCAPE = 2
LOG2_3 = math.log2(3.0)


def v2(n: int) -> int:
    return (n & -n).bit_length() - 1


def next_odd(n: int) -> int:
    raw = 3 * n + 1
    return raw >> v2(raw)


def compute_status(power: int) -> bytearray:
    n_max = 1 << power
    status = bytearray(n_max >> 1)
    status[0] = REACH
    for n in range(3, n_max, 2):
        idx = n >> 1
        if status[idx] != UNKNOWN:
            continue
        path: list[int] = []
        cur = n
        while True:
            if cur > n_max:
                result = ESCAPE
                break
            cur_idx = cur >> 1
            if status[cur_idx] != UNKNOWN:
                result = status[cur_idx]
                break
            path.append(cur_idx)
            cur = next_odd(cur)
        for path_idx in path:
            status[path_idx] = result
    return status


def load_status(power: int, cache_dir: Path, existing_cache_dir: Path) -> bytearray:
    name = f"odd_only_status_p{power}.bin"
    expected = 1 << (power - 1)
    for directory in (cache_dir, existing_cache_dir):
        path = directory / name
        if path.exists() and path.stat().st_size == expected:
            print(f"loading {path}")
            return bytearray(path.read_bytes())
    print(f"computing status p={power}")
    status = compute_status(power)
    cache_dir.mkdir(parents=True, exist_ok=True)
    (cache_dir / name).write_bytes(status)
    return status


def layer_bounds(power: int, h: int) -> tuple[int, int, int]:
    bit_length = power - h
    lo = (1 << (bit_length - 1)) + 1
    hi = (1 << bit_length) - 1
    total = ((hi - lo) >> 1) + 1
    return lo, hi, total


def trace_escape(n: int, n_max: int) -> tuple[int, ...]:
    ks: list[int] = []
    cur = n
    while cur <= n_max:
        raw = 3 * cur + 1
        k = v2(raw)
        ks.append(k)
        cur = raw >> k
        if len(ks) > 100_000:
            raise RuntimeError("unexpectedly long escape path")
    return tuple(ks)


def key_for(word: tuple[int, ...], depth: int) -> tuple[int, ...]:
    # Zero is a terminal marker when escape occurs before the requested depth.
    if depth == 0:
        return word + (0,)
    return word[:depth] if len(word) >= depth else word + (0,)


def word_text(word: tuple[int, ...]) -> str:
    if word and word[-1] == 0:
        return ",".join(map(str, word[:-1])) + "|E"
    return ",".join(map(str, word))


def exact_iid_full_word_mass(marked_word: tuple[int, ...], h: int) -> float:
    """Unconditional iid mass for a valuation word whose final step is first passage."""
    word = marked_word[:-1] if marked_word and marked_word[-1] == 0 else marked_word
    cumulative_k = 0
    max_prior_position = -math.inf
    for step, k in enumerate(word, 1):
        cumulative_k += k
        position = step * LOG2_3 - cumulative_k
        if step < len(word):
            max_prior_position = max(max_prior_position, position)
        else:
            final_position = position
    lower = max(0.5, 2.0 ** (h - final_position))
    upper = 1.0
    if max_prior_position > -math.inf:
        upper = min(upper, 2.0 ** (h - max_prior_position))
    y_probability = max(0.0, 2.0 * (upper - lower))
    return (2.0 ** (-cumulative_k)) * y_probability


def actual_escape_counts(
    power: int, h: int, status: bytearray, depths: tuple[int, ...]
) -> tuple[int, dict[int, Counter[tuple[int, ...]]], dict[str, Counter[int]]]:
    lo, hi, _ = layer_bounds(power, h)
    start = lo >> 1
    end = (hi >> 1) + 1
    counts = {depth: Counter() for depth in depths}
    budget = {"exhausted": Counter(), "within": Counter()}
    escapes = 0
    bit_budget = power - h
    for idx in range(start, end):
        if status[idx] != ESCAPE:
            continue
        escapes += 1
        word = trace_escape(2 * idx + 1, 1 << power)
        for depth in depths:
            counts[depth][key_for(word, depth)] += 1
        label = "exhausted" if sum(word) >= bit_budget else "within"
        budget[label][sum(word)] += 1
    return escapes, counts, budget


def tilted_k(rng: random.Random) -> int:
    k = 1
    while rng.random() < 0.25:
        k += 1
    return k


def iid_escape_sample(
    h: int, samples: int, depths: tuple[int, ...], rng: random.Random
) -> tuple[dict[int, defaultdict[tuple[int, ...], float]], dict[str, defaultdict[int, float]], float, float]:
    weighted = {depth: defaultdict(float) for depth in depths}
    budget = {"exhausted": defaultdict(float), "within": defaultdict(float)}
    sum_w = 0.0
    sum_w2 = 0.0
    bit_budget_placeholder = 0  # classified later per p from K histogram
    del bit_budget_placeholder
    for _ in range(samples):
        y = 0.5 + 0.5 * rng.random()
        distance = h - math.log2(y)
        position = 0.0
        word_list: list[int] = []
        while position <= distance:
            k = tilted_k(rng)
            word_list.append(k)
            position += LOG2_3 - k
        word = tuple(word_list)
        overshoot = position - distance
        weight = y * (2.0 ** (-overshoot))
        sum_w += weight
        sum_w2 += weight * weight
        for depth in depths:
            weighted[depth][key_for(word, depth)] += weight
        budget["within"][sum(word)] += weight  # K histogram; relabeled per p later
    mean_w = sum_w / samples
    se_w = math.sqrt(max(0.0, sum_w2 / samples - mean_w * mean_w) / samples)
    return weighted, budget, mean_w, se_w


def distribution_metrics(
    actual: Counter[tuple[int, ...]], iid_weight: dict[tuple[int, ...], float],
    iid_total_weight: float, iid_samples: int
) -> dict[str, float]:
    actual_total = sum(actual.values())
    keys = set(actual) | set(iid_weight)
    tv = 0.5 * sum(
        abs(actual.get(key, 0) / actual_total - iid_weight.get(key, 0.0) / iid_total_weight)
        for key in keys
    )
    # Monte Carlo can leave tiny actual categories unseen. Report an explicit
    # half-effective-sample smoothing rather than an artificial infinite KL.
    epsilon = 0.5 / max(iid_samples, 1)
    q_raw = {key: iid_weight.get(key, 0.0) / iid_total_weight for key in keys}
    q_norm = 1.0 + epsilon * len(keys)
    kl = 0.0
    actual_unseen = 0.0
    for key in keys:
        p = actual.get(key, 0) / actual_total
        if p == 0.0:
            continue
        if iid_weight.get(key, 0.0) == 0.0:
            actual_unseen += p
        q = (q_raw[key] + epsilon) / q_norm
        kl += p * math.log(p / q)
    return {"tv": tv, "kl_smoothed_nats": kl, "actual_mass_unseen_iid_mc": actual_unseen}


def cylinder_residue(word: tuple[int, ...]) -> tuple[int, int]:
    """Unique odd residue modulo 2^(sum(k)+1) realizing a valuation prefix."""
    r = 1
    cumulative_k = 0
    prefix: list[int] = []
    for k in word:
        if k == 0:
            break
        cur = r
        for prior_k in prefix:
            cur = (3 * cur + 1) >> prior_k
        modulus_k = 1 << k
        a_half = (3 * cur + 1) >> 1
        odd_coefficient = pow(3, len(prefix) + 1)
        target = 1 << (k - 1)
        t = ((target - a_half) * pow(odd_coefficient, -1, modulus_k)) % modulus_k
        r += t * (1 << (cumulative_k + 1))
        cumulative_k += k
        prefix.append(k)
    modulus = 1 << (cumulative_k + 1)
    # Verify the constructed cylinder representative.
    cur = r
    for k in prefix:
        if v2(3 * cur + 1) != k:
            raise AssertionError((word, r, k, cur))
        cur = (3 * cur + 1) >> k
    return r % modulus, modulus


def count_residue(lo: int, hi: int, residue: int, modulus: int) -> int:
    first = lo + ((residue - lo) % modulus)
    return 0 if first > hi else 1 + (hi - first) // modulus


def iter_residue(lo: int, hi: int, residue: int, modulus: int, limit: int) -> Iterable[int]:
    first = lo + ((residue - lo) % modulus)
    if first > hi:
        return
    count = 0
    for n in range(first, hi + 1, modulus):
        yield n
        count += 1
        if count >= limit:
            return


def classify_reach(n: int, n_max: int, layer_lo: int, long_steps: int = 50) -> tuple[str, int]:
    cur = n
    steps = 0
    while True:
        cur = next_odd(cur)
        steps += 1
        if cur > n_max:
            return "escape", steps
        if cur == 1:
            return ("long_then_absorb_1" if steps > long_steps else "absorb_1"), steps
        if cur < layer_lo:
            return ("long_then_below_layer" if steps > long_steps else "coalesce_below_layer"), steps
        if cur < n:
            return ("long_then_lower_orbit" if steps > long_steps else "coalesce_lower_within_layer"), steps


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--powers", nargs="+", type=int, default=[24, 25, 26, 27, 28])
    parser.add_argument("--hs", nargs="+", type=int, default=[2, 3, 4, 5, 6])
    parser.add_argument("--depths", nargs="+", type=int, default=[4, 6, 8, 10])
    parser.add_argument("--iid-samples", type=int, default=500_000)
    parser.add_argument("--top-words", type=int, default=25)
    parser.add_argument("--classification-limit", type=int, default=100_000)
    parser.add_argument("--seed", type=int, default=20260625)
    parser.add_argument("--cache-dir", type=Path, default=Path("work/status_cache"))
    parser.add_argument(
        "--existing-cache-dir", type=Path,
        default=Path(r"C:\Users\yauki\Documents\Codex\2026-06-25\new-chat-2\work\status_cache"),
    )
    parser.add_argument("--out-dir", type=Path, default=Path("outputs"))
    args = parser.parse_args()

    depths = tuple(sorted(set(args.depths)))
    rng = random.Random(args.seed)
    iid_by_h = {}
    print("sampling iid tilted escape paths")
    for h in args.hs:
        iid_by_h[h] = iid_escape_sample(h, args.iid_samples, depths, rng)
        print(f"  h={h}: iid Q={iid_by_h[h][2]:.6f} +/- {iid_by_h[h][3]:.6f}")

    metric_rows: list[dict[str, object]] = []
    deficit_rows: list[dict[str, object]] = []
    budget_rows: list[dict[str, object]] = []
    parity_source: dict[tuple[int, int, int, tuple[int, ...]], tuple[float, float]] = {}
    actual_saved: dict[tuple[int, int, int], Counter[tuple[int, ...]]] = {}

    for power in args.powers:
        status = load_status(power, args.cache_dir, args.existing_cache_dir)
        for h in args.hs:
            lo, hi, total = layer_bounds(power, h)
            escapes, actual_counts, actual_budget = actual_escape_counts(power, h, status, depths)
            iid_counts, iid_budget_raw, iid_q, iid_q_se = iid_by_h[h]
            iid_total_weight = iid_q * args.iid_samples
            actual_q = (escapes / total) * (2**h)
            print(f"p={power} h={h}: escapes={escapes} Q={actual_q:.6f}, iid={iid_q:.6f}")

            for label, predicate in (
                ("K_tau_lt_bit_budget", lambda k, b=power-h: k < b),
                ("K_tau_ge_bit_budget", lambda k, b=power-h: k >= b),
            ):
                actual_n = sum(count for k, count in (actual_budget["within"] | actual_budget["exhausted"]).items() if predicate(k))
                iid_w = sum(weight for k, weight in iid_budget_raw["within"].items() if predicate(k))
                actual_mass = actual_n / total
                iid_mass = (2.0 ** (-h)) * iid_w / args.iid_samples
                budget_rows.append({
                    "power": power, "h": h, "stratum": label,
                    "actual_escape_count": actual_n, "actual_unconditional_mass": actual_mass,
                    "iid_unconditional_mass": iid_mass,
                    "actual_to_iid_ratio": actual_mass / iid_mass if iid_mass else float("nan"),
                    "mass_deficit_actual_minus_iid": actual_mass - iid_mass,
                    "share_of_actual_escapes": actual_n / escapes if escapes else float("nan"),
                    "share_of_iid_escapes": iid_w / iid_total_weight if iid_total_weight else float("nan"),
                })

            for depth in depths:
                actual = actual_counts[depth]
                iid_weight = iid_counts[depth]
                metrics = distribution_metrics(actual, iid_weight, iid_total_weight, args.iid_samples)
                metric_rows.append({
                    "power": power, "h": h, "depth": depth,
                    "layer_total": total, "actual_escape_count": escapes,
                    "actual_Q": actual_q, "iid_Q": iid_q, "iid_Q_MC_SE": iid_q_se,
                    "Q_deficit_actual_minus_iid": actual_q - iid_q,
                    "conditional_TV": metrics["tv"],
                    "conditional_KL_smoothed_nats": metrics["kl_smoothed_nats"],
                    "actual_conditional_mass_unseen_in_iid_MC": metrics["actual_mass_unseen_iid_mc"],
                    "actual_word_types": len(actual), "iid_sample_word_types": len(iid_weight),
                })
                rows_here = []
                for word in set(actual) | set(iid_weight):
                    actual_count = actual.get(word, 0)
                    actual_mass = actual_count / total
                    iid_mass = (
                        exact_iid_full_word_mass(word, h)
                        if depth == 0
                        else (2.0 ** (-h)) * iid_weight.get(word, 0.0) / args.iid_samples
                    )
                    deficit = actual_mass - iid_mass
                    row = {
                        "power": power, "h": h, "depth": depth, "word": word_text(word),
                        "terminal_before_depth": int(bool(word and word[-1] == 0)),
                        "sum_k_observed_prefix": sum(word), "actual_count": actual_count,
                        "actual_unconditional_mass": actual_mass, "iid_unconditional_mass": iid_mass,
                        "actual_to_iid_ratio": actual_mass / iid_mass if iid_mass else float("inf"),
                        "mass_difference_actual_minus_iid": deficit,
                        "Q_contribution_difference": deficit * (2**h),
                        "actual_conditional_probability": actual_count / escapes if escapes else 0.0,
                        "iid_conditional_probability": (
                            iid_mass / (iid_q * (2.0 ** (-h)))
                            if depth == 0
                            else iid_weight.get(word, 0.0) / iid_total_weight
                        ),
                        "rank_kind": "",
                    }
                    rows_here.append((deficit, word, row))
                    parity_source[(power, h, depth, word)] = (actual_mass, iid_mass)
                selected: list[tuple[float, tuple[int, ...], dict[str, object]]] = []
                for item in sorted(rows_here, key=lambda item: item[0])[: args.top_words]:
                    item[2]["rank_kind"] = "largest_deficit"
                    selected.append(item)
                for item in sorted(rows_here, key=lambda item: item[0], reverse=True)[: args.top_words]:
                    copy = dict(item[2])
                    copy["rank_kind"] = "largest_excess"
                    selected.append((item[0], item[1], copy))
                deficit_rows.extend(item[2] for item in selected)
                if power == max(args.powers):
                    actual_saved[(power, h, depth)] = actual
        del status

    # Finite cylinder and outcome checks for the most negative p=max(p) words.
    cylinder_rows: list[dict[str, object]] = []
    outcome_rows: list[dict[str, object]] = []
    focus_power = max(args.powers)
    status = load_status(focus_power, args.cache_dir, args.existing_cache_dir)
    for h in args.hs:
        lo, hi, total = layer_bounds(focus_power, h)
        for depth in depths:
            candidates = [row for row in deficit_rows if row["power"] == focus_power and row["h"] == h and row["depth"] == depth and row["rank_kind"] == "largest_deficit"]
            for rank, row in enumerate(sorted(candidates, key=lambda r: float(r["mass_difference_actual_minus_iid"]))[:10], 1):
                clean = str(row["word"]).replace("|E", "")
                word = tuple(int(part) for part in clean.split(",") if part)
                residue, modulus = cylinder_residue(word)
                finite_count = count_residue(lo, hi, residue, modulus)
                iid_expected = total * (2.0 ** (-sum(word)))
                actual_escape_count = int(row["actual_count"])
                cylinder_rows.append({
                    "power": focus_power, "h": h, "depth": depth, "deficit_rank": rank,
                    "word": row["word"], "sum_k": sum(word), "bit_budget": focus_power-h,
                    "cylinder_residue": residue, "cylinder_modulus": modulus,
                    "residue_cylinder_count": 1, "finite_layer_realization_count": finite_count,
                    "iid_expected_realization_count": iid_expected,
                    "finite_to_iid_realization_ratio": finite_count / iid_expected if iid_expected else float("nan"),
                    "actual_escape_count": actual_escape_count,
                    "escape_fraction_within_realized_cylinder": actual_escape_count / finite_count if finite_count else float("nan"),
                })
                outcomes = Counter()
                step_sum = Counter()
                sampled = 0
                for n in iter_residue(lo, hi, residue, modulus, args.classification_limit):
                    category, steps = classify_reach(n, 1 << focus_power, lo)
                    outcomes[category] += 1
                    step_sum[category] += steps
                    sampled += 1
                for category, count in outcomes.items():
                    outcome_rows.append({
                        "power": focus_power, "h": h, "depth": depth, "deficit_rank": rank,
                        "word": row["word"], "finite_layer_realization_count": finite_count,
                        "classified_sample": sampled, "category": category, "count": count,
                        "fraction": count / sampled if sampled else float("nan"),
                        "mean_steps_to_category": step_sum[category] / count,
                    })
    del status

    parity_rows: list[dict[str, object]] = []
    for h in args.hs:
        for depth in depths:
            words = {key[3] for key in parity_source if key[1] == h and key[2] == depth}
            contrasts = []
            for word in words:
                even = []
                odd = []
                for power in args.powers:
                    actual_mass, iid_mass = parity_source.get((power, h, depth, word), (0.0, 0.0))
                    target = even if power % 2 == 0 else odd
                    target.append((actual_mass - iid_mass) * (2**h))
                if not even or not odd:
                    continue
                even_mean = sum(even) / len(even)
                odd_mean = sum(odd) / len(odd)
                contrasts.append((abs(even_mean - odd_mean), word, even_mean, odd_mean))
            for rank, (_, word, even_mean, odd_mean) in enumerate(sorted(contrasts, reverse=True)[:25], 1):
                parity_rows.append({
                    "h": h, "depth": depth, "contrast_rank": rank, "word": word_text(word),
                    "even_p_mean_Q_contribution_deficit": even_mean,
                    "odd_p_mean_Q_contribution_deficit": odd_mean,
                    "even_minus_odd": even_mean - odd_mean,
                    "powers": ";".join(map(str, args.powers)),
                })

    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.out_dir / "collatz_escape_prefix_metrics.csv", metric_rows)
    write_csv(args.out_dir / "collatz_escape_word_deficits.csv", deficit_rows)
    write_csv(args.out_dir / "collatz_bit_budget_strata.csv", budget_rows)
    write_csv(args.out_dir / "collatz_finite_layer_cylinders.csv", cylinder_rows)
    write_csv(args.out_dir / "collatz_absorption_coalescence.csv", outcome_rows)
    write_csv(args.out_dir / "collatz_p_parity_diagnostic.csv", parity_rows)
    print("wrote diagnostic CSV files")


if __name__ == "__main__":
    main()
