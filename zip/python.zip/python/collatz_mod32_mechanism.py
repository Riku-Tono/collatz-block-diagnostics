from __future__ import annotations

import argparse
import csv
import math
from collections import Counter
from pathlib import Path


UNKNOWN = 0
REACH = 1
ESCAPE = 2


def v2(n: int) -> int:
    return (n & -n).bit_length() - 1


def next_odd_with_k(n: int) -> tuple[int, int]:
    m = 3 * n + 1
    k = v2(m)
    return m >> k, k


def compute_status(power: int) -> bytearray:
    n_max = 1 << power
    status = bytearray(n_max >> 1)
    status[0] = REACH
    for n in range(3, n_max + 1, 2):
        idx = n >> 1
        if status[idx] != UNKNOWN:
            continue
        path: list[int] = []
        cur = n
        while True:
            if cur > n_max:
                result = ESCAPE
                break
            cur_idx = cur >> 1
            if status[cur_idx] != UNKNOWN:
                result = status[cur_idx]
                break
            path.append(cur_idx)
            cur, _ = next_odd_with_k(cur)
        for path_idx in path:
            status[path_idx] = result
    return status


def pearson(xs: list[float], ys: list[float]) -> float:
    xb = sum(xs) / len(xs)
    yb = sum(ys) / len(ys)
    num = sum((x - xb) * (y - yb) for x, y in zip(xs, ys))
    denx = sum((x - xb) ** 2 for x in xs)
    deny = sum((y - yb) ** 2 for y in ys)
    return num / math.sqrt(denx * deny) if denx and deny else float("nan")


def rank(values: list[float]) -> list[float]:
    order = sorted(range(len(values)), key=values.__getitem__)
    ranks = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and values[order[j]] == values[order[i]]:
            j += 1
        avg = (i + j - 1) / 2 + 1
        for pos in order[i:j]:
            ranks[pos] = avg
        i = j
    return ranks


def color_for_q(q: float, q_min: float, q_max: float) -> str:
    t = (math.log(q) - math.log(q_min)) / (math.log(q_max) - math.log(q_min))
    r = round(45 + 210 * t)
    g = round(105 - 55 * t)
    b = round(200 - 150 * t)
    return f"#{r:02x}{g:02x}{b:02x}"


def write_svg(path: Path, modulus: int, residues: tuple[int, ...], q_by_residue: dict[int, float], transitions: dict[int, Counter[int]], threshold: float) -> None:
    width = height = 900
    cx = cy = 450
    radius = 335
    positions: dict[int, tuple[float, float]] = {}
    for i, residue in enumerate(residues):
        angle = -math.pi / 2 + 2 * math.pi * i / len(residues)
        positions[residue] = (cx + radius * math.cos(angle), cy + radius * math.sin(angle))
    q_min = min(q_by_residue.values())
    q_max = max(q_by_residue.values())
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#fafafa"/>',
        '<defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><polygon points="0 0, 7 3.5, 0 7" fill="#667085"/></marker></defs>',
        f'<text x="450" y="34" text-anchor="middle" font-family="sans-serif" font-size="21">mod {modulus} weighted Syracuse transitions</text>',
        f'<text x="450" y="60" text-anchor="middle" font-family="sans-serif" font-size="14">edges shown when P(target | source) >= {threshold:.2f}; node color = log Q</text>',
    ]
    for source in residues:
        total = sum(transitions[source].values())
        x1, y1 = positions[source]
        for target, count in transitions[source].items():
            prob = count / total
            if prob < threshold:
                continue
            x2, y2 = positions[target]
            dx, dy = x2 - x1, y2 - y1
            length = math.hypot(dx, dy) or 1
            ux, uy = dx / length, dy / length
            sx, sy = x1 + ux * 29, y1 + uy * 29
            ex, ey = x2 - ux * 34, y2 - uy * 34
            opacity = 0.25 + 0.65 * min(1.0, prob / 0.5)
            stroke_width = 0.8 + 4.0 * prob
            parts.append(f'<line x1="{sx:.1f}" y1="{sy:.1f}" x2="{ex:.1f}" y2="{ey:.1f}" stroke="#667085" stroke-opacity="{opacity:.2f}" stroke-width="{stroke_width:.2f}" marker-end="url(#arrow)"/>')
    for residue in residues:
        x, y = positions[residue]
        q = q_by_residue[residue]
        fill = color_for_q(q, q_min, q_max)
        parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="28" fill="{fill}" stroke="#101828" stroke-width="1.5"/>')
        parts.append(f'<text x="{x:.1f}" y="{y - 2:.1f}" text-anchor="middle" font-family="sans-serif" font-size="14" font-weight="bold" fill="white">{residue}</text>')
        parts.append(f'<text x="{x:.1f}" y="{y + 15:.1f}" text-anchor="middle" font-family="sans-serif" font-size="10" fill="white">Q={q:.3f}</text>')
    parts.append('</svg>')
    path.write_text("\n".join(parts), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--power", type=int, default=26)
    parser.add_argument("--h", type=int, default=3)
    parser.add_argument("--depth", type=int, default=4)
    parser.add_argument("--modulus", type=int, choices=[32, 64], default=32)
    parser.add_argument("--out-dir", type=Path, default=Path("outputs"))
    args = parser.parse_args()

    n_max = 1 << args.power
    bit_length = args.power - args.h
    lo = (1 << (bit_length - 1)) + 1
    hi = (1 << bit_length) - 1
    status = compute_status(args.power)

    residues = tuple(range(1, args.modulus, 2))
    totals = Counter()
    misses = Counter()
    k_counts = {r: Counter() for r in residues}
    transitions = {r: Counter() for r in residues}
    sums = {d: {r: Counter() for r in residues} for d in range(1, args.depth + 1)}

    log2_3 = math.log2(3)
    for n in range(lo, hi + 1, 2):
        source = n % args.modulus
        totals[source] += 1
        if status[n >> 1] == ESCAPE:
            misses[source] += 1
        cur = n
        cumulative_k = 0
        max_k = 0
        max_prefix_log_growth = -float("inf")
        for d in range(1, args.depth + 1):
            nxt, k = next_odd_with_k(cur)
            if d == 1:
                k_counts[source][k] += 1
                transitions[source][nxt % args.modulus] += 1
            cumulative_k += k
            max_k = max(max_k, k)
            prefix_log_growth = d * log2_3 - cumulative_k
            max_prefix_log_growth = max(max_prefix_log_growth, prefix_log_growth)
            s = sums[d][source]
            s["sum_k"] += cumulative_k
            s["max_k"] += max_k
            s["terminal_log_growth"] += prefix_log_growth
            s["max_prefix_log_growth"] += max_prefix_log_growth
            s["odd_cross"] += int(nxt > n_max)
            s["peak_cross"] += int(3 * cur + 1 > n_max)
            cur = nxt

    args.out_dir.mkdir(parents=True, exist_ok=True)
    q_by_residue = {r: (misses[r] / totals[r]) * (2**args.h) for r in residues}

    summary_rows = []
    for r in residues:
        total = totals[r]
        kc = k_counts[r]
        mean_k1 = sum(k * count for k, count in kc.items()) / total
        entropy = -sum((count / total) * math.log2(count / total) for count in transitions[r].values())
        row: dict[str, int | float | str] = {
            "power": args.power, "h": args.h, "residue": r, "total": total,
            "misses": misses[r], "Q": q_by_residue[r], "mean_k1": mean_k1,
            "k1_distribution": ";".join(f"{k}:{kc[k]/total:.8f}" for k in sorted(kc)),
            "transition_targets": len(transitions[r]), "transition_entropy_bits": entropy,
            "one_step_growth_prob": sum(count for k, count in kc.items() if k == 1) / total,
            "one_step_mean_multiplier": sum((3 / (2**k)) * count for k, count in kc.items()) / total,
            "one_step_odd_escape_rate": sums[1][r]["odd_cross"] / total,
            "one_step_peak_escape_rate": sums[1][r]["peak_cross"] / total,
        }
        for d in range(1, args.depth + 1):
            s = sums[d][r]
            row[f"d{d}_mean_k"] = s["sum_k"] / (total * d)
            row[f"d{d}_mean_max_k"] = s["max_k"] / total
            row[f"d{d}_mean_terminal_log2_multiplier"] = s["terminal_log_growth"] / total
            row[f"d{d}_mean_max_prefix_log2_growth"] = s["max_prefix_log_growth"] / total
            row[f"d{d}_odd_cross_rate"] = s["odd_cross"] / total
            row[f"d{d}_peak_cross_rate"] = s["peak_cross"] / total
        summary_rows.append(row)

    stem = f"collatz_mod{args.modulus}"
    summary_path = args.out_dir / f"{stem}_features.csv"
    with summary_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0]))
        writer.writeheader()
        writer.writerows(summary_rows)

    transition_rows = []
    for source in residues:
        total = totals[source]
        for target in residues:
            count = transitions[source][target]
            transition_rows.append({"source": source, "target": target, "count": count, "probability": count / total})
    transition_path = args.out_dir / f"{stem}_transitions.csv"
    with transition_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(transition_rows[0]))
        writer.writeheader()
        writer.writerows(transition_rows)

    qs = [q_by_residue[r] for r in residues]
    log_qs = [math.log2(q) for q in qs]
    feature_names = [
        "mean_k1", "one_step_mean_multiplier", "transition_entropy_bits",
        *[f"d{d}_mean_k" for d in range(1, args.depth + 1)],
        *[f"d{d}_mean_terminal_log2_multiplier" for d in range(1, args.depth + 1)],
        *[f"d{d}_mean_max_prefix_log2_growth" for d in range(1, args.depth + 1)],
        *[f"d{d}_peak_cross_rate" for d in range(1, args.depth + 1)],
    ]
    correlation_rows = []
    for name in feature_names:
        values = [float(row[name]) for row in summary_rows]
        correlation_rows.append({
            "feature": name,
            "pearson_with_Q": pearson(values, qs),
            "pearson_with_log2Q": pearson(values, log_qs),
            "spearman_with_Q": pearson(rank(values), rank(qs)),
        })
    correlation_rows.sort(key=lambda row: abs(float(row["pearson_with_log2Q"])), reverse=True)
    correlation_path = args.out_dir / f"{stem}_correlations.csv"
    with correlation_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(correlation_rows[0]))
        writer.writeheader()
        writer.writerows(correlation_rows)

    write_svg(args.out_dir / f"{stem}_transition_graph.svg", args.modulus, residues, q_by_residue, transitions, 0.12)

    print(f"layer: [{lo}, {hi}], odd starts={sum(totals.values())}")
    print("residue  Q        mean_k1  targets  entropy")
    for row in summary_rows:
        print(f"{int(row['residue']):7d}  {float(row['Q']):.6f}  {float(row['mean_k1']):7.3f}  {int(row['transition_targets']):7d}  {float(row['transition_entropy_bits']):7.3f}")
    print("\ntop correlations with log2(Q):")
    for row in correlation_rows[:8]:
        print(f"{row['feature']:42s} {float(row['pearson_with_log2Q']): .6f}")


if __name__ == "__main__":
    main()
