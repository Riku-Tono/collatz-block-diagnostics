from __future__ import annotations

import csv
import importlib.util
import math
import random
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(r"C:\Users\yauki\Documents\design\Collatz\py")
SRC = ROOT / "py" / "collatz_escape_word_deficit.py"
CSV_DIR = ROOT / "csv"
OUT_DIR = Path("outputs")
SEED = 20260625
IID_SAMPLES = 500_000
CLASSIFICATION_LIMIT = 10_000


def load_source():
    spec = importlib.util.spec_from_file_location("collatz_escape_word_deficit", SRC)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {SRC}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_csv(name: str) -> list[dict[str, str]]:
    with (CSV_DIR / name).open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def unique_metric_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    seen = set()
    out = []
    for row in rows:
        key = (row["power"], row["h"])
        if key in seen:
            continue
        seen.add(key)
        out.append(row)
    return out


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else float("nan")


def parse_word(text: str) -> tuple[int, ...]:
    clean = text.replace("|E", "")
    return tuple(int(part) for part in clean.split(",") if part)


def first_residue_value(lo: int, residue: int, modulus: int) -> int:
    return lo + ((residue - lo) % modulus)


def sample_residue_values(
    lo: int,
    hi: int,
    residue: int,
    modulus: int,
    mode: str,
    limit: int,
    rng: random.Random,
) -> list[int]:
    first = first_residue_value(lo, residue, modulus)
    if first > hi:
        return []
    count = 1 + (hi - first) // modulus
    sample_n = min(limit, count)
    if mode == "front":
        indices = list(range(sample_n))
    elif mode == "even":
        if sample_n == count:
            indices = list(range(count))
        elif sample_n == 1:
            indices = [count // 2]
        else:
            indices = sorted({round(i * (count - 1) / (sample_n - 1)) for i in range(sample_n)})
            j = 0
            while len(indices) < sample_n:
                indices.append(j)
                j += 1
            indices = sorted(indices[:sample_n])
    elif mode == "random":
        indices = sorted(rng.sample(range(count), sample_n))
    else:
        raise ValueError(mode)
    return [first + idx * modulus for idx in indices]


def classify_sample(module, row: dict[str, str], mode: str, rng: random.Random) -> list[dict[str, object]]:
    power = int(row["power"])
    h = int(row["h"])
    word = parse_word(row["word"])
    lo, hi, _ = module.layer_bounds(power, h)
    residue, modulus = module.cylinder_residue(word)
    values = sample_residue_values(lo, hi, residue, modulus, mode, CLASSIFICATION_LIMIT, rng)
    outcomes: Counter[str] = Counter()
    steps: Counter[str] = Counter()
    for n in values:
        category, step_count = module.classify_reach(n, 1 << power, lo)
        outcomes[category] += 1
        steps[category] += step_count
    out = []
    for category, count in sorted(outcomes.items()):
        out.append(
            {
                "power": power,
                "h": h,
                "depth": row["depth"],
                "deficit_rank": row["deficit_rank"],
                "word": row["word"],
                "sample_mode": mode,
                "sample_size": len(values),
                "category": category,
                "count": count,
                "fraction": count / len(values) if values else float("nan"),
                "mean_steps_to_category": steps[category] / count,
            }
        )
    return out


def main() -> None:
    module = load_source()
    metrics = unique_metric_rows(read_csv("collatz_escape_prefix_metrics.csv"))
    strata = read_csv("collatz_bit_budget_strata.csv")
    cylinders = read_csv("collatz_finite_layer_cylinders.csv")

    summary_rows: list[dict[str, object]] = []
    metric_by_key = {(int(r["power"]), int(r["h"])): r for r in metrics}
    strata_by_key: dict[tuple[int, int], dict[str, dict[str, str]]] = defaultdict(dict)
    for row in strata:
        strata_by_key[(int(row["power"]), int(row["h"]))][row["stratum"]] = row

    for key in sorted(strata_by_key):
        power, h = key
        metric = metric_by_key[key]
        within = strata_by_key[key]["K_tau_lt_bit_budget"]
        exhausted = strata_by_key[key]["K_tau_ge_bit_budget"]
        exhausted_q = float(exhausted["mass_deficit_actual_minus_iid"]) * (2**h)
        net_deficit = float(metric["Q_deficit_actual_minus_iid"])
        summary_rows.append(
            {
                "power": power,
                "h": h,
                "actual_Q": metric["actual_Q"],
                "iid_Q": metric["iid_Q"],
                "net_Q_deficit_actual_minus_iid": net_deficit,
                "ratio_K_tau_lt_bit_budget": within["actual_to_iid_ratio"],
                "ratio_K_tau_ge_bit_budget": exhausted["actual_to_iid_ratio"],
                "exhausted_stratum_Q_contribution": exhausted_q,
                "exhausted_share_of_net_deficit": exhausted_q / net_deficit if net_deficit else float("nan"),
            }
        )
    write_csv(OUT_DIR / "collatz_review_strata_summary_p24_p28.csv", summary_rows)

    parity_rows: list[dict[str, object]] = []
    for h in sorted({int(r["h"]) for r in metrics}):
        for stratum in ("overall", "K_tau_lt_bit_budget", "K_tau_ge_bit_budget"):
            even_values: list[float] = []
            odd_values: list[float] = []
            for power in sorted({int(r["power"]) for r in metrics}):
                if (power, h) not in metric_by_key:
                    continue
                if stratum == "overall":
                    value = float(metric_by_key[(power, h)]["Q_deficit_actual_minus_iid"])
                else:
                    row = strata_by_key[(power, h)][stratum]
                    value = float(row["mass_deficit_actual_minus_iid"]) * (2**h)
                (even_values if power % 2 == 0 else odd_values).append(value)
            parity_rows.append(
                {
                    "h": h,
                    "stratum": stratum,
                    "even_p_mean_Q_deficit": mean(even_values),
                    "odd_p_mean_Q_deficit": mean(odd_values),
                    "even_minus_odd": mean(even_values) - mean(odd_values),
                    "even_count": len(even_values),
                    "odd_count": len(odd_values),
                    "powers": "24;25;26;27;28",
                }
            )
    write_csv(OUT_DIR / "collatz_review_parity_by_stratum_p24_p28.csv", parity_rows)

    mass_rows: list[dict[str, object]] = []
    for key, by_stratum in sorted(strata_by_key.items()):
        power, h = key
        metric = metric_by_key[key]
        actual_mass_sum = sum(float(r["actual_unconditional_mass"]) for r in by_stratum.values())
        iid_mass_sum = sum(float(r["iid_unconditional_mass"]) for r in by_stratum.values())
        actual_mass_from_q = float(metric["actual_Q"]) / (2**h)
        iid_mass_from_q = float(metric["iid_Q"]) / (2**h)
        mass_rows.append(
            {
                "power": power,
                "h": h,
                "actual_mass_sum_strata": actual_mass_sum,
                "actual_mass_from_Q": actual_mass_from_q,
                "actual_mass_abs_error": actual_mass_sum - actual_mass_from_q,
                "iid_mass_sum_strata": iid_mass_sum,
                "iid_mass_from_Q": iid_mass_from_q,
                "iid_mass_abs_error": iid_mass_sum - iid_mass_from_q,
            }
        )
    write_csv(OUT_DIR / "collatz_review_mass_conservation_p24_p28.csv", mass_rows)

    # Compare the old front-of-cylinder sampling with two less biased modes.
    rng = random.Random(SEED)
    selected = [
        row
        for row in cylinders
        if row["power"] == "28" and row["depth"] in {"4", "8"} and int(row["deficit_rank"]) <= 3
    ]
    sample_rows: list[dict[str, object]] = []
    for row in selected:
        for mode in ("front", "even", "random"):
            sample_rows.extend(classify_sample(module, row, mode, rng))
    write_csv(OUT_DIR / "collatz_review_absorption_sampling_comparison.csv", sample_rows)

    report = OUT_DIR / "collatz_review_followup_report.md"
    max_actual_err = max(abs(float(r["actual_mass_abs_error"])) for r in mass_rows)
    max_iid_err = max(abs(float(r["iid_mass_abs_error"])) for r in mass_rows)
    report.write_text(
        "\n".join(
            [
                "# Collatz Review Follow-up",
                "",
                "Date: 2026-06-25",
                "",
                "## Scope",
                "",
                "This follow-up weakens the causal wording.  The verified claim is localization: "
                "the actual-minus-iid deficit is concentrated in the exhaustion region `K_tau >= p-h`. "
                "It does not claim that finite-bit exhaustion is the unique cause.",
                "",
                "The exact re-aggregation here uses the existing p=24..28 CSV outputs.  No p=29/p=30 exact status cache was available in this workspace.",
                "",
                "## Reproducibility metadata",
                "",
                "- Source script: `C:/Users/yauki/Documents/design/Collatz/py/py/collatz_escape_word_deficit.py`",
                "- Original command shape: `python collatz_escape_word_deficit.py --powers 24 25 26 27 28 --hs 2 3 4 5 6 --depths 4 6 8 10 --iid-samples 500000 --seed 20260625`",
                f"- iid samples: {IID_SAMPLES}",
                f"- random seed: {SEED}",
                "- status cache used by source default: `C:/Users/yauki/Documents/Codex/2026-06-25/new-chat-2/work/status_cache`",
                "- p,h range re-aggregated here: p=24..28, h=2..6",
                f"- max actual mass conservation error: {max_actual_err:.3e}",
                f"- max iid mass conservation error: {max_iid_err:.3e}",
                "",
                "## Outputs",
                "",
                "- `collatz_review_strata_summary_p24_p28.csv`: actual Q, iid Q, stratum ratios, exhausted contribution, and net deficit.",
                "- `collatz_review_parity_by_stratum_p24_p28.csv`: even/odd comparison overall and within each K_tau stratum.",
                "- `collatz_review_mass_conservation_p24_p28.csv`: mass preservation check for the strata split.",
                "- `collatz_review_absorption_sampling_comparison.csv`: front, equal-spaced, and seed-fixed random cylinder sampling comparison.",
                "",
                "## Interim judgment",
                "",
                "Strong: deficit localization in `K_tau >= p-h`; near-unit actual/iid ratio in `K_tau < p-h`; short valuation cylinder realization counts match finite-layer expectations.",
                "",
                "Not established: finite-bit exhaustion as the unique cause; asymptotic p-parity; causal mod-3 cutoff mechanism.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(report)


if __name__ == "__main__":
    main()
