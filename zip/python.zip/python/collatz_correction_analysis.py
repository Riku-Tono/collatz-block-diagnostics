from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

from collatz_global_q_analysis import ols, write_csv


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def through_origin(xs: list[float], ys: list[float]) -> tuple[float, float]:
    coefficient = sum(x * y for x, y in zip(xs, ys)) / sum(x * x for x in xs)
    rmse = math.sqrt(sum((y - coefficient * x) ** 2 for x, y in zip(xs, ys)) / len(ys))
    return coefficient, rmse


def fit_summary(name: str, design: list[list[float]], ys: list[float]) -> dict[str, str | float | int]:
    beta, rmse = ols(design, ys)
    return {
        "scope": "p>=24,h=2..6",
        "model": name,
        "n": len(ys),
        "coefficients": ";".join(f"{value:.12g}" for value in beta),
        "RMSE": rmse,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path("outputs/collatz_global_q_p18_p28.csv"))
    parser.add_argument("--c0", type=float, default=0.6235)
    parser.add_argument("--out-dir", type=Path, default=Path("outputs"))
    args = parser.parse_args()

    source = read_rows(args.input)
    residual_rows: list[dict[str, int | float | str]] = []
    for row in source:
        q = float(row["Q"])
        se = float(row["Q_binomial_SE"])
        delta = q - args.c0
        residual_rows.append(
            {
                "C0": args.c0,
                "power": int(row["power"]),
                "h": int(row["h"]),
                "bit_length": int(row["bit_length"]),
                "total": int(row["total"]),
                "escapes": int(row["escapes"]),
                "Q": q,
                "Q_binomial_SE": se,
                "Delta_Q_minus_C0": delta,
                "Delta_over_SE": delta / se if se else float("nan"),
                "h_over_p": int(row["h"]) / int(row["power"]),
                "two_to_h_minus_p": 2.0 ** (int(row["h"]) - int(row["power"])),
                "source": row["source"],
            }
        )
    write_csv(args.out_dir / "collatz_C_residuals.csv", residual_rows)

    target = [
        row for row in residual_rows
        if int(row["power"]) >= 24 and 2 <= int(row["h"]) <= 6
    ]
    ys = [float(row["Delta_Q_minus_C0"]) for row in target]
    pooled_fits = [
        fit_summary("constant", [[1.0] for _ in target], ys),
        fit_summary("a+b*h", [[1.0, float(row["h"])] for row in target], ys),
        fit_summary("a+b*h/p", [[1.0, float(row["h_over_p"])] for row in target], ys),
        fit_summary("a+b*2^(h-p)", [[1.0, float(row["two_to_h_minus_p"])] for row in target], ys),
        fit_summary(
            "a+b/p+c*h/p",
            [[1.0, 1.0 / int(row["power"]), float(row["h_over_p"])] for row in target],
            ys,
        ),
    ]
    write_csv(args.out_dir / "collatz_C_residual_pooled_fits.csv", pooled_fits)

    p28 = sorted(
        (row for row in residual_rows if int(row["power"]) == 28 and 2 <= int(row["h"]) <= 6),
        key=lambda row: int(row["h"]),
    )
    p28_y = [float(row["Delta_Q_minus_C0"]) for row in p28]
    p28_fits = [
        fit_summary("a+b*h", [[1.0, float(row["h"])] for row in p28], p28_y),
        fit_summary("a+b*h+c*h^2", [[1.0, float(row["h"]), float(row["h"]) ** 2] for row in p28], p28_y),
    ]
    for row in p28_fits:
        row["scope"] = "p=28,h=2..6"
    write_csv(args.out_dir / "collatz_C_residual_p28_fits.csv", p28_fits)

    fixed_h_rows: list[dict[str, int | float | str]] = []
    for h in range(2, 7):
        selected = sorted(
            (row for row in residual_rows if int(row["power"]) >= 24 and int(row["h"]) == h),
            key=lambda row: int(row["power"]),
        )
        ps = [float(row["power"]) for row in selected]
        deltas = [float(row["Delta_Q_minus_C0"]) for row in selected]
        constant, constant_rmse = ols([[1.0] for _ in selected], deltas)
        inv_coefficient, inv_rmse = through_origin([1.0 / p for p in ps], deltas)
        exponential_coefficient, exponential_rmse = through_origin([2.0 ** (-p) for p in ps], deltas)
        free_inv, free_inv_rmse = ols([[1.0, 1.0 / p] for p in ps], deltas)
        fixed_h_rows.append(
            {
                "h": h,
                "p_values": ";".join(str(int(p)) for p in ps),
                "Delta_values": ";".join(f"{delta:.9f}" for delta in deltas),
                "constant_delta": constant[0],
                "constant_RMSE": constant_rmse,
                "O_1_over_p_coefficient": inv_coefficient,
                "O_1_over_p_RMSE": inv_rmse,
                "O_2_minus_p_coefficient": exponential_coefficient,
                "O_2_minus_p_RMSE": exponential_rmse,
                "free_intercept_plus_1_over_p_intercept": free_inv[0],
                "free_intercept_plus_1_over_p_coefficient": free_inv[1],
                "free_intercept_plus_1_over_p_RMSE": free_inv_rmse,
            }
        )
    write_csv(args.out_dir / "collatz_C_residual_fixed_h_fits.csv", fixed_h_rows)

    print("p=28 residuals")
    for row in p28:
        print(
            f"h={int(row['h'])}: Q={float(row['Q']):.9f}, "
            f"Delta={float(row['Delta_Q_minus_C0']):+.9f}, "
            f"SE={float(row['Q_binomial_SE']):.9f}, "
            f"z={float(row['Delta_over_SE']):+.2f}"
        )
    print("\np=28 fits")
    for row in p28_fits:
        print(f"{row['model']}: beta={row['coefficients']}, RMSE={float(row['RMSE']):.9f}")
    print("\npooled fits")
    for row in pooled_fits:
        print(f"{row['model']}: beta={row['coefficients']}, RMSE={float(row['RMSE']):.9f}")


if __name__ == "__main__":
    main()
