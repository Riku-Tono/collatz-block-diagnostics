from __future__ import annotations

import csv
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean, pstdev


OUT_DIR = Path("outputs")
CELLS = OUT_DIR / "collatz_tail_by_tau_cells.csv"
LOG2_3 = math.log2(3.0)
DRIFT_BIN_WIDTH = 0.25
MEAN_K_BIN_WIDTH = 0.05
MIN_IID_MASS = 1e-6


def read_cells() -> list[dict[str, object]]:
    rows = []
    with CELLS.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            power = int(row["power"])
            h = int(row["h"])
            k = int(row["K"])
            tau = int(row["tau"])
            actual_mass = float(row["actual_mass"])
            iid_mass = float(row["iid_mass"])
            drift = tau * LOG2_3 - k
            mean_k = k / tau
            rows.append(
                {
                    "power": power,
                    "h": h,
                    "K": k,
                    "tau": tau,
                    "relative_K": int(row["relative_K"]),
                    "actual_mass": actual_mass,
                    "iid_mass": iid_mass,
                    "drift_delta": drift,
                    "mean_k": mean_k,
                    "drift_bin": math.floor(drift / DRIFT_BIN_WIDTH) * DRIFT_BIN_WIDTH,
                    "mean_k_bin": math.floor(mean_k / MEAN_K_BIN_WIDTH) * MEAN_K_BIN_WIDTH,
                    "p_parity": "even" if power % 2 == 0 else "odd",
                }
            )
    return rows


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def group_ratio(rows: list[dict[str, object]], key_fields: list[str]) -> list[dict[str, object]]:
    grouped: dict[tuple[object, ...], dict[str, float]] = defaultdict(lambda: {"actual": 0.0, "iid": 0.0})
    for row in rows:
        key = tuple(row[field] for field in key_fields)
        grouped[key]["actual"] += float(row["actual_mass"])
        grouped[key]["iid"] += float(row["iid_mass"])
    out = []
    for key, mass in sorted(grouped.items()):
        iid = mass["iid"]
        result = {field: value for field, value in zip(key_fields, key)}
        result.update(
            {
                "actual_mass": mass["actual"],
                "iid_mass": iid,
                "survival_ratio": mass["actual"] / iid if iid else "",
            }
        )
        out.append(result)
    return out


def tail_by_cut(
    rows: list[dict[str, object]],
    axis: str,
    cuts: list[float],
    direction: str,
    key_fields: list[str] | None = None,
) -> list[dict[str, object]]:
    key_fields = key_fields or []
    grouped_keys = sorted({tuple(row[field] for field in key_fields) for row in rows}) or [()]
    out = []
    for key in grouped_keys:
        subset = [row for row in rows if tuple(row[field] for field in key_fields) == key]
        for cut in cuts:
            if direction == "ge":
                selected = [row for row in subset if float(row[axis]) >= cut]
            elif direction == "le":
                selected = [row for row in subset if float(row[axis]) <= cut]
            else:
                raise ValueError(direction)
            actual = sum(float(row["actual_mass"]) for row in selected)
            iid = sum(float(row["iid_mass"]) for row in selected)
            result = {field: value for field, value in zip(key_fields, key)}
            result.update(
                {
                    f"{axis}_cut": cut,
                    "direction": direction,
                    "actual_tail_mass": actual,
                    "iid_tail_mass": iid,
                    "tail_survival_ratio": actual / iid if iid else "",
                }
            )
            out.append(result)
    return out


def monotonicity_score(points: list[tuple[float, float, float]], decreasing: bool) -> float:
    filtered = [(x, y) for x, y, iid in points if iid >= MIN_IID_MASS and math.isfinite(y)]
    filtered.sort()
    if len(filtered) < 3:
        return float("nan")
    good = 0
    total = 0
    for (_x0, y0), (_x1, y1) in zip(filtered, filtered[1:]):
        if decreasing:
            good += int(y1 <= y0)
        else:
            good += int(y1 >= y0)
        total += 1
    return good / total if total else float("nan")


def collapse_cv(rows: list[dict[str, object]], axis_field: str, group_field: str | None = "h") -> float:
    by_axis: dict[object, list[float]] = defaultdict(list)
    for row in rows:
        iid = float(row.get("iid_mass", row.get("iid_tail_mass", 0.0)))
        if iid < MIN_IID_MASS:
            continue
        ratio_text = row.get("survival_ratio", row.get("tail_survival_ratio", ""))
        if ratio_text == "":
            continue
        by_axis[row[axis_field]].append(float(ratio_text))
    cvs = []
    weights = []
    for axis, vals in by_axis.items():
        if len(vals) < 2:
            continue
        m = mean(vals)
        if m:
            cvs.append(pstdev(vals) / abs(m))
            weights.append(len(vals))
    return sum(c * w for c, w in zip(cvs, weights)) / sum(weights) if weights else float("nan")


def write_svg(path: Path, series: dict[str, list[tuple[float, float]]], title: str, x_label: str, y_label: str, y_min: float = 0.75, y_max: float = 1.2) -> None:
    width, height = 920, 560
    left, right, top, bottom = 76, 30, 46, 68
    all_x = [x for points in series.values() for x, _ in points]
    if not all_x:
        return
    x_min, x_max = min(all_x), max(all_x)
    if x_min == x_max:
        x_min -= 1
        x_max += 1

    def sx(x: float) -> float:
        return left + (x - x_min) * (width - left - right) / (x_max - x_min)

    def sy(y: float) -> float:
        y = max(y_min, min(y_max, y))
        return top + (y_max - y) * (height - top - bottom) / (y_max - y_min)

    colors = ["#2563eb", "#dc2626", "#16a34a", "#9333ea", "#ea580c", "#0f766e", "#334155"]
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        f'<text x="{width/2}" y="27" text-anchor="middle" font-family="Arial" font-size="18">{title}</text>',
    ]
    for y in [0.8, 0.9, 1.0, 1.1]:
        yy = sy(y)
        parts.append(f'<line x1="{left}" y1="{yy:.2f}" x2="{width-right}" y2="{yy:.2f}" stroke="#e5e7eb"/>')
        parts.append(f'<text x="{left-10}" y="{yy+4:.2f}" text-anchor="end" font-family="Arial" font-size="11">{y:.2f}</text>')
    parts.append(f'<line x1="{left}" y1="{height-bottom}" x2="{width-right}" y2="{height-bottom}" stroke="#111827"/>')
    parts.append(f'<line x1="{left}" y1="{top}" x2="{left}" y2="{height-bottom}" stroke="#111827"/>')
    parts.append(f'<line x1="{left}" y1="{sy(1.0):.2f}" x2="{width-right}" y2="{sy(1.0):.2f}" stroke="#6b7280" stroke-dasharray="4 4"/>')
    if x_min <= 0 <= x_max:
        parts.append(f'<line x1="{sx(0):.2f}" y1="{top}" x2="{sx(0):.2f}" y2="{height-bottom}" stroke="#111827" stroke-dasharray="4 4"/>')
    for i, (label, points) in enumerate(series.items()):
        color = colors[i % len(colors)]
        pts = " ".join(f"{sx(x):.2f},{sy(y):.2f}" for x, y in sorted(points))
        parts.append(f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="2"/>')
        lx, ly = width - right - 175, top + 18 + i * 18
        parts.append(f'<line x1="{lx}" y1="{ly-4}" x2="{lx+22}" y2="{ly-4}" stroke="{color}" stroke-width="2"/>')
        parts.append(f'<text x="{lx+28}" y="{ly}" font-family="Arial" font-size="12">{label}</text>')
    parts.append(f'<text x="{width/2}" y="{height-18}" text-anchor="middle" font-family="Arial" font-size="13">{x_label}</text>')
    parts.append(f'<text x="18" y="{height/2}" transform="rotate(-90 18 {height/2})" text-anchor="middle" font-family="Arial" font-size="13">{y_label}</text>')
    parts.append("</svg>")
    path.write_text("\n".join(parts), encoding="utf-8")


def summarize_axis(name: str, rows: list[dict[str, object]], axis_field: str, expected_decreasing: bool) -> dict[str, object]:
    points = []
    for row in rows:
        ratio = row.get("survival_ratio", row.get("tail_survival_ratio", ""))
        if ratio == "":
            continue
        iid = float(row.get("iid_mass", row.get("iid_tail_mass", 0.0)))
        points.append((float(row[axis_field]), float(ratio), iid))
    stable = [ratio for _x, ratio, iid in points if iid >= MIN_IID_MASS and math.isfinite(ratio)]
    return {
        "axis": name,
        "stable_bin_count": len(stable),
        "ratio_min": min(stable) if stable else "",
        "ratio_max": max(stable) if stable else "",
        "ratio_range": (max(stable) - min(stable)) if stable else "",
        "monotonicity_score": monotonicity_score(points, expected_decreasing),
        "collapse_cv_by_axis": collapse_cv(rows, axis_field),
    }


def conditional_tables(rows: list[dict[str, object]]) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    # x_K windows: before, boundary, deep exhausted. Inside each, test drift bins.
    x_windows = [("pre", -6, -1), ("boundary", 0, 5), ("deep", 6, 18)]
    cond_x_drift = []
    for label, lo, hi in x_windows:
        subset = [row for row in rows if lo <= int(row["relative_K"]) <= hi]
        for b in sorted({float(row["drift_bin"]) for row in subset}):
            selected = [row for row in subset if float(row["drift_bin"]) == b]
            actual = sum(float(row["actual_mass"]) for row in selected)
            iid = sum(float(row["iid_mass"]) for row in selected)
            if iid:
                cond_x_drift.append(
                    {
                        "x_window": label,
                        "x_min": lo,
                        "x_max": hi,
                        "drift_bin": b,
                        "actual_mass": actual,
                        "iid_mass": iid,
                        "survival_ratio": actual / iid,
                    }
                )
    # Drift windows: negative/near/positive. Inside each, test x_K bins.
    drift_windows = [("negative", -20.0, -2.0), ("near_zero", -2.0, 2.0), ("positive", 2.0, 20.0)]
    cond_drift_x = []
    for label, lo, hi in drift_windows:
        subset = [row for row in rows if lo <= float(row["drift_delta"]) < hi]
        for x in sorted({int(row["relative_K"]) for row in subset}):
            selected = [row for row in subset if int(row["relative_K"]) == x]
            actual = sum(float(row["actual_mass"]) for row in selected)
            iid = sum(float(row["iid_mass"]) for row in selected)
            if iid:
                cond_drift_x.append(
                    {
                        "drift_window": label,
                        "drift_min": lo,
                        "drift_max": hi,
                        "relative_K": x,
                        "actual_mass": actual,
                        "iid_mass": iid,
                        "survival_ratio": actual / iid,
                    }
                )
    return cond_x_drift, cond_drift_x


def main() -> None:
    rows = read_cells()

    drift_bins = group_ratio(rows, ["drift_bin"])
    drift_bins_h = group_ratio(rows, ["h", "drift_bin"])
    drift_bins_parity = group_ratio(rows, ["p_parity", "drift_bin"])
    mean_bins = group_ratio(rows, ["mean_k_bin"])
    mean_bins_h = group_ratio(rows, ["h", "mean_k_bin"])

    drift_cuts = [round(-12 + i * 0.5, 2) for i in range(49)]
    mean_cuts = [round(1.0 + i * 0.05, 2) for i in range(41)]
    drift_tail = tail_by_cut(rows, "drift_delta", drift_cuts, "ge")
    drift_tail_h = tail_by_cut(rows, "drift_delta", drift_cuts, "ge", ["h"])
    drift_tail_parity = tail_by_cut(rows, "drift_delta", drift_cuts, "ge", ["p_parity"])
    mean_tail = tail_by_cut(rows, "mean_k", mean_cuts, "le")
    mean_tail_h = tail_by_cut(rows, "mean_k", mean_cuts, "le", ["h"])

    cond_x_drift, cond_drift_x = conditional_tables(rows)

    # Axis comparison includes already-generated x_K/tau summaries when possible.
    tau_bins = group_ratio(rows, ["tau"])
    x_bins = group_ratio(rows, ["relative_K"])
    comparison = [
        summarize_axis("x_K_pointwise", x_bins, "relative_K", True),
        summarize_axis("tau_pointwise", tau_bins, "tau", True),
        summarize_axis("drift_delta_bin", drift_bins, "drift_bin", False),
        summarize_axis("mean_k_bin", mean_bins, "mean_k_bin", False),
        summarize_axis("drift_delta_tail_ge", drift_tail, "drift_delta_cut", False),
        summarize_axis("mean_k_tail_le", mean_tail, "mean_k_cut", False),
    ]

    write_csv(OUT_DIR / "collatz_tail_by_drift_bins.csv", drift_bins)
    write_csv(OUT_DIR / "collatz_tail_by_drift_bins_by_h.csv", drift_bins_h)
    write_csv(OUT_DIR / "collatz_tail_by_drift_bins_parity.csv", drift_bins_parity)
    write_csv(OUT_DIR / "collatz_tail_by_drift_tail.csv", drift_tail)
    write_csv(OUT_DIR / "collatz_tail_by_drift_tail_by_h.csv", drift_tail_h)
    write_csv(OUT_DIR / "collatz_tail_by_drift_tail_parity.csv", drift_tail_parity)
    write_csv(OUT_DIR / "collatz_tail_by_mean_k_bins.csv", mean_bins)
    write_csv(OUT_DIR / "collatz_tail_by_mean_k_bins_by_h.csv", mean_bins_h)
    write_csv(OUT_DIR / "collatz_tail_by_mean_k_tail.csv", mean_tail)
    write_csv(OUT_DIR / "collatz_tail_by_mean_k_tail_by_h.csv", mean_tail_h)
    write_csv(OUT_DIR / "collatz_conditional_xK_by_drift.csv", cond_x_drift)
    write_csv(OUT_DIR / "collatz_conditional_drift_by_xK.csv", cond_drift_x)
    write_csv(OUT_DIR / "collatz_axis_comparison_summary.csv", comparison)

    drift_series = {
        "all": [
            (float(r["drift_bin"]), float(r["survival_ratio"]))
            for r in drift_bins
            if float(r["iid_mass"]) >= MIN_IID_MASS and -12 <= float(r["drift_bin"]) <= 4
        ]
    }
    write_svg(OUT_DIR / "collatz_drift_delta_collapse.svg", drift_series, "Survival by drift_delta bin", "drift_delta bin", "actual / iid")

    drift_tail_series = {
        "all": [
            (float(r["drift_delta_cut"]), float(r["tail_survival_ratio"]))
            for r in drift_tail
            if float(r["iid_tail_mass"]) >= MIN_IID_MASS and -12 <= float(r["drift_delta_cut"]) <= 8
        ]
    }
    write_svg(OUT_DIR / "collatz_drift_delta_tail.svg", drift_tail_series, "Tail survival by drift_delta cutoff", "drift_delta cutoff", "actual / iid")

    parity_series = {}
    for parity in ("even", "odd"):
        parity_series[parity] = [
            (float(r["drift_delta_cut"]), float(r["tail_survival_ratio"]))
            for r in drift_tail_parity
            if r["p_parity"] == parity and float(r["iid_tail_mass"]) >= MIN_IID_MASS and -12 <= float(r["drift_delta_cut"]) <= 8
        ]
    write_svg(OUT_DIR / "collatz_drift_delta_tail_parity.svg", parity_series, "Drift tail survival by p parity", "drift_delta cutoff", "actual / iid")

    by_h_series = {}
    for h in sorted({int(r["h"]) for r in drift_tail_h}):
        by_h_series[f"h={h}"] = [
            (float(r["drift_delta_cut"]), float(r["tail_survival_ratio"]))
            for r in drift_tail_h
            if int(r["h"]) == h and float(r["iid_tail_mass"]) >= MIN_IID_MASS and -12 <= float(r["drift_delta_cut"]) <= 8
        ]
    write_svg(OUT_DIR / "collatz_drift_delta_tail_by_h.svg", by_h_series, "Drift tail survival by h", "drift_delta cutoff", "actual / iid")

    report = OUT_DIR / "collatz_tail_by_drift_report.md"
    drift_near = [r for r in drift_tail if -4 <= float(r["drift_delta_cut"]) <= 6 and float(r["iid_tail_mass"]) >= MIN_IID_MASS]
    mean_near = [r for r in mean_tail if 1.0 <= float(r["mean_k_cut"]) <= 2.2 and float(r["iid_tail_mass"]) >= MIN_IID_MASS]
    lines = [
        "# Collatz Tail by Drift",
        "",
        "This checks whether the exhausted-tail deficit is better explained by cumulative growth drift than by K or tau alone.",
        "",
        "Definitions:",
        "",
        "```text",
        "drift_delta = tau * log2(3) - K_tau",
        "mean_k = K_tau / tau",
        "multiplier = 2^drift_delta",
        "```",
        "",
        "## Drift Tail",
        "",
        "| drift_delta cutoff y | S_tail(drift>=y) | actual tail mass | iid tail mass |",
        "|---:|---:|---:|---:|",
    ]
    for r in drift_near:
        lines.append(
            f"| {float(r['drift_delta_cut']):.2f} | {float(r['tail_survival_ratio']):.6f} | "
            f"{float(r['actual_tail_mass']):.8g} | {float(r['iid_tail_mass']):.8g} |"
        )
    lines.extend(
        [
            "",
            "## Mean-k Tail",
            "",
            "Lower mean_k is more expansion-heavy.",
            "",
            "| mean_k cutoff a | S_tail(mean_k<=a) | actual tail mass | iid tail mass |",
            "|---:|---:|---:|---:|",
        ]
    )
    for r in mean_near:
        lines.append(
            f"| {float(r['mean_k_cut']):.2f} | {float(r['tail_survival_ratio']):.6f} | "
            f"{float(r['actual_tail_mass']):.8g} | {float(r['iid_tail_mass']):.8g} |"
        )
    lines.extend(
        [
            "",
            "## Axis Comparison",
            "",
            "| axis | stable bins | ratio range | monotonicity | collapse CV |",
            "|---|---:|---:|---:|---:|",
        ]
    )
    for r in comparison:
        lines.append(
            f"| {r['axis']} | {r['stable_bin_count']} | {float(r['ratio_range']):.6f} | "
            f"{float(r['monotonicity_score']):.3f} | {float(r['collapse_cv_by_axis']):.6f} |"
        )
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "Use this as a scalar-axis diagnostic only. If drift or mean_k gives cleaner monotone ratios than x_K or tau, the deficit is better described as depletion of sustained expansion-heavy words. If not, prefix arithmetic or higher-dimensional structure remains likely.",
        ]
    )
    report.write_text("\n".join(lines), encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
