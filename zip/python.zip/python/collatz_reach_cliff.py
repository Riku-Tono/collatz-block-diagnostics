from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path


UNKNOWN = 0
REACH = 1
ESCAPE = 2


def next_odd(n: int) -> int:
    m = 3 * n + 1
    return m >> ((m & -m).bit_length() - 1)


def compute_status(max_power: int) -> bytearray:
    n_max = 1 << max_power
    odd_count = n_max >> 1
    status = bytearray(odd_count)
    status[0] = REACH

    for n in range(3, n_max + 1, 2):
        idx = n >> 1
        if status[idx] != UNKNOWN:
            continue

        path: list[int] = []
        cur = n
        result = UNKNOWN
        while True:
            if cur > n_max:
                result = ESCAPE
                break

            cur_idx = cur >> 1
            cur_status = status[cur_idx]
            if cur_status != UNKNOWN:
                result = cur_status
                break

            path.append(cur_idx)
            cur = next_odd(cur)

        for path_idx in path:
            status[path_idx] = result

    return status


def summarize(max_power: int, status: bytearray) -> list[dict[str, float | int]]:
    n_max = 1 << max_power
    rows = []
    for bit_length in range(1, max_power + 1):
        lo = 1 << (bit_length - 1)
        hi = min((1 << bit_length) - 1, n_max)
        if lo % 2 == 0:
            lo += 1
        if lo > hi:
            continue

        total = 0
        reached = 0
        for n in range(lo, hi + 1, 2):
            total += 1
            if status[n >> 1] == REACH:
                reached += 1

        reach = reached / total
        miss = 1.0 - reach
        h = max_power - bit_length
        rows.append(
            {
                "N_power": max_power,
                "bit_length": bit_length,
                "h": h,
                "total": total,
                "reached": reached,
                "reach": reach,
                "R_miss": miss,
                "Q_R_times_2h": miss * (2**h),
            }
        )
    return rows


def fit_slope(rows: list[dict[str, float | int]], h_min: int, h_max: int) -> tuple[float, float, int]:
    xs = []
    ys = []
    for row in rows:
        h = int(row["h"])
        r = float(row["R_miss"])
        if h_min <= h <= h_max and r > 0.0:
            xs.append(h)
            ys.append(math.log2(r))

    n = len(xs)
    if n < 2:
        return float("nan"), float("nan"), n

    xbar = sum(xs) / n
    ybar = sum(ys) / n
    denom = sum((x - xbar) ** 2 for x in xs)
    slope = sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys)) / denom
    intercept = ybar - slope * xbar
    return -slope, intercept, n


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--powers", nargs="+", type=int, default=[18, 20, 22, 24])
    parser.add_argument("--h-min", type=int, default=2)
    parser.add_argument("--h-max", type=int, default=8)
    parser.add_argument("--out", type=Path, default=Path("work/reach_cliff_summary.csv"))
    args = parser.parse_args()

    all_rows: list[dict[str, float | int]] = []
    print("definition: odd Syracuse orbit reaches 1 without odd node exceeding N=2^p")
    for power in args.powers:
        status = compute_status(power)
        rows = summarize(power, status)
        all_rows.extend(rows)
        theta, intercept, fit_n = fit_slope(rows, args.h_min, args.h_max)

        print(f"\nN=2^{power}")
        print(f"fit h={args.h_min}..{args.h_max}: theta={theta:.5f}, intercept={intercept:.5f}, points={fit_n}")
        print("h  bit_length  reach       R_miss      Q=R*2^h")
        for row in rows:
            h = int(row["h"])
            if 0 <= h <= 10:
                print(
                    f"{h:2d} {int(row['bit_length']):10d} "
                    f"{float(row['reach']):.6f}  {float(row['R_miss']):.6f}  "
                    f"{float(row['Q_R_times_2h']):.6f}"
                )

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(all_rows[0].keys()))
        writer.writeheader()
        writer.writerows(all_rows)
    print(f"\nwrote {args.out}")


if __name__ == "__main__":
    main()
