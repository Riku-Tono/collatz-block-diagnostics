from __future__ import annotations

import argparse
import csv
import math
import statistics
from pathlib import Path

from collatz_oos_validation import REACH, load_or_compute_status


def write_csv(path: Path, rows: list[dict[str, int | float | str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def extract_power(power: int, h_max: int, cache_dir: Path) -> list[dict[str, int | float | str]]:
    status = load_or_compute_status(power, cache_dir)
    rows = []
    for h in range(0, min(h_max, power - 1) + 1):
        bit_length = power - h
        lo = 1 << (bit_length - 1)
        if lo % 2 == 0:
            lo += 1
        hi = (1 << bit_length) - 1
        start = lo >> 1
        end = (hi >> 1) + 1
        total = end - start
        reached = status.count(REACH, start, end)
        escapes = total - reached
        miss = escapes / total
        q = miss * (2**h)
        q_se = (2**h) * math.sqrt(miss * (1.0 - miss) / total)
        rows.append(
            {
                "power": power,
                "N": 1 << power,
                "h": h,
                "bit_length": bit_length,
                "total": total,
                "reached": reached,
                "escapes": escapes,
                "R_miss": miss,
                "Q": q,
                "Q_binomial_SE": q_se,
                "source": "status_cache",
            }
        )
    del status
    return rows


def read_odd_power_rows(path: Path, h_max: int) -> list[dict[str, int | float | str]]:
    rows = []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            if row["modulus"] != "all":
                continue
            h = int(row["h"])
            if h > h_max:
                continue
            total = int(row["total"])
            reached = int(row["reached"])
            escapes = total - reached
            miss = float(row["R_miss"])
            rows.append(
                {
                    "power": int(row["N_power"]),
                    "N": int(row["N"]),
                    "h": h,
                    "bit_length": int(row["bit_length"]),
                    "total": total,
                    "reached": reached,
                    "escapes": escapes,
                    "R_miss": miss,
                    "Q": float(row["Q_R_times_2h"]),
                    "Q_binomial_SE": (2**h) * math.sqrt(miss * (1.0 - miss) / total),
                    "source": "existing_odd_power_csv",
                }
            )
    return rows


def solve_linear(matrix: list[list[float]], vector: list[float]) -> list[float]:
    n = len(vector)
    augmented = [row[:] + [value] for row, value in zip(matrix, vector)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(augmented[row][col]))
        augmented[col], augmented[pivot] = augmented[pivot], augmented[col]
        scale = augmented[col][col]
        for j in range(col, n + 1):
            augmented[col][j] /= scale
        for row in range(n):
            if row == col:
                continue
            factor = augmented[row][col]
            for j in range(col, n + 1):
                augmented[row][j] -= factor * augmented[col][j]
    return [augmented[i][n] for i in range(n)]


def ols(design: list[list[float]], ys: list[float]) -> tuple[list[float], float]:
    columns = len(design[0])
    xtx = [[0.0] * columns for _ in range(columns)]
    xty = [0.0] * columns
    for xs, y in zip(design, ys):
        for i in range(columns):
            xty[i] += xs[i] * y
            for j in range(columns):
                xtx[i][j] += xs[i] * xs[j]
    beta = solve_linear(xtx, xty)
    predictions = [sum(coef * x for coef, x in zip(beta, xs)) for xs in design]
    rmse = math.sqrt(sum((y - prediction) ** 2 for y, prediction in zip(ys, predictions)) / len(ys))
    return beta, rmse


def build_fit_rows(even_rows: list[dict[str, int | float | str]], consecutive_rows: list[dict[str, int | float | str]]) -> list[dict[str, int | float | str]]:
    fits = []
    for h in range(2, 7):
        even = sorted((row for row in even_rows if int(row["h"]) == h), key=lambda row: int(row["power"]))
        high = [row for row in even if int(row["power"]) >= 24]
        consecutive = sorted((row for row in consecutive_rows if int(row["h"]) == h), key=lambda row: int(row["power"]))

        ps = [float(row["power"]) for row in even]
        qs = [float(row["Q"]) for row in even]
        constant = statistics.mean(qs)
        constant_rmse = math.sqrt(sum((q - constant) ** 2 for q in qs) / len(qs))
        inv_beta, inv_rmse = ols([[1.0, 1.0 / p] for p in ps], qs)

        high_ps = [float(row["power"]) for row in high]
        high_qs = [float(row["Q"]) for row in high]
        high_beta, high_rmse = ols([[1.0, 1.0 / p] for p in high_ps], high_qs)

        all_ps = [float(row["power"]) for row in consecutive]
        all_qs = [float(row["Q"]) for row in consecutive]
        base_beta, base_rmse = ols([[1.0, 1.0 / p] for p in all_ps], all_qs)
        parity_beta, parity_rmse = ols(
            [[1.0, 1.0 / p, (-1.0) ** int(p)] for p in all_ps], all_qs
        )
        fits.append(
            {
                "h": h,
                "even_p_count": len(even),
                "constant_fit_C": constant,
                "constant_fit_RMSE": constant_rmse,
                "inv_p_fit_C_all_even": inv_beta[0],
                "inv_p_fit_a_all_even": inv_beta[1],
                "inv_p_fit_RMSE_all_even": inv_rmse,
                "inv_p_fit_C_p24_p28": high_beta[0],
                "inv_p_fit_a_p24_p28": high_beta[1],
                "inv_p_fit_RMSE_p24_p28": high_rmse,
                "last_three_mean_p24_p28": statistics.mean(high_qs),
                "last_three_range_p24_p28": max(high_qs) - min(high_qs),
                "consecutive_p_count": len(consecutive),
                "consecutive_inv_p_C": base_beta[0],
                "consecutive_inv_p_a": base_beta[1],
                "consecutive_inv_p_RMSE": base_rmse,
                "parity_fit_C": parity_beta[0],
                "parity_fit_a": parity_beta[1],
                "parity_amplitude_b": parity_beta[2],
                "parity_fit_RMSE": parity_rmse,
                "parity_RMSE_ratio": parity_rmse / base_rmse if base_rmse else float("nan"),
            }
        )
    return fits


def build_h_shape_rows(even_rows: list[dict[str, int | float | str]]) -> list[dict[str, int | float | str]]:
    result = []
    for power in sorted({int(row["power"]) for row in even_rows}):
        rows = sorted((row for row in even_rows if int(row["power"]) == power), key=lambda row: int(row["h"]))
        by_h = {int(row["h"]): row for row in rows}
        plateau = [float(by_h[h]["Q"]) for h in range(2, 7)]
        beta, rmse = ols([[1.0, float(h)] for h in range(2, 7)], plateau)
        result.append(
            {
                "power": power,
                "Q_h0": float(by_h[0]["Q"]),
                "Q_h1": float(by_h[1]["Q"]),
                "mean_Q_h2_h6": statistics.mean(plateau),
                "range_Q_h2_h6": max(plateau) - min(plateau),
                "linear_slope_per_h_h2_h6": beta[1],
                "linear_RMSE_h2_h6": rmse,
                "Q_h7": float(by_h[7]["Q"]),
                "Q_h8": float(by_h[8]["Q"]),
                "Q_h9": float(by_h[9]["Q"]),
                "Q_h10": float(by_h[10]["Q"]),
                "escapes_h10": int(by_h[10]["escapes"]),
                "total_h10": int(by_h[10]["total"]),
                "relative_SE_h10": float(by_h[10]["Q_binomial_SE"]) / float(by_h[10]["Q"]) if float(by_h[10]["Q"]) else float("inf"),
            }
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--powers", nargs="+", type=int, default=[18, 20, 22, 24, 26, 28])
    parser.add_argument("--h-max", type=int, default=10)
    parser.add_argument("--cache-dir", type=Path, default=Path("work/status_cache"))
    parser.add_argument("--out-dir", type=Path, default=Path("outputs"))
    parser.add_argument(
        "--odd-power-source",
        type=Path,
        default=Path(r"C:\Users\yauki\Documents\Codex\2026-06-25\c\work\reach_study_p19_p27_odd.csv"),
    )
    args = parser.parse_args()

    even_rows = []
    for power in args.powers:
        even_rows.extend(extract_power(power, args.h_max, args.cache_dir))
    even_rows.sort(key=lambda row: (int(row["power"]), int(row["h"])))
    write_csv(args.out_dir / "collatz_global_q_even_p.csv", even_rows)

    consecutive_rows = even_rows[:]
    if args.odd_power_source.exists():
        consecutive_rows.extend(read_odd_power_rows(args.odd_power_source, args.h_max))
    consecutive_rows.sort(key=lambda row: (int(row["power"]), int(row["h"])))
    write_csv(args.out_dir / "collatz_global_q_p18_p28.csv", consecutive_rows)

    fits = build_fit_rows(even_rows, consecutive_rows)
    write_csv(args.out_dir / "collatz_global_q_p_fits.csv", fits)
    shapes = build_h_shape_rows(even_rows)
    write_csv(args.out_dir / "collatz_global_q_h_shapes.csv", shapes)

    wide_rows = []
    for power in args.powers:
        selected = {int(row["h"]): float(row["Q"]) for row in even_rows if int(row["power"]) == power}
        wide_rows.append({"power": power, **{f"Q_h{h}": selected[h] for h in range(args.h_max + 1)}})
    write_csv(args.out_dir / "collatz_global_q_wide.csv", wide_rows)

    print("p  " + "  ".join(f"h={h}" for h in range(args.h_max + 1)))
    for row in wide_rows:
        print(f"{int(row['power']):2d} " + " ".join(f"{float(row[f'Q_h{h}']):.6f}" for h in range(args.h_max + 1)))
    print("\nh  C_const  C+a/p(all)  C+a/p(p>=24)  last3mean  parity_b  parity_RMSE/base")
    for row in fits:
        print(
            f"{int(row['h']):1d}  {float(row['constant_fit_C']):.6f}  "
            f"{float(row['inv_p_fit_C_all_even']):.6f}      "
            f"{float(row['inv_p_fit_C_p24_p28']):.6f}       "
            f"{float(row['last_three_mean_p24_p28']):.6f}   "
            f"{float(row['parity_amplitude_b']):+.6f}   "
            f"{float(row['parity_RMSE_ratio']):.3f}"
        )


if __name__ == "__main__":
    main()
