from __future__ import annotations

import argparse
import csv
import math
import random
from pathlib import Path


def tilted_k(rng: random.Random) -> int:
    # Exponential tilt at the Cramer root theta=1 (base 2):
    # q(k) = p(k) * 2^(log2(3)-k) = 3 / 4^k.
    k = 1
    while rng.random() < 0.25:
        k += 1
    return k


def estimate(height: float, samples: int, rng: random.Random) -> dict[str, float | int]:
    log2_3 = math.log2(3.0)
    total = 0.0
    total_sq = 0.0
    total_overshoot = 0.0
    total_steps = 0
    layer_total = 0.0
    layer_total_sq = 0.0
    layer_steps = 0
    for _ in range(samples):
        position = 0.0
        steps = 0
        while position <= height:
            position += log2_3 - tilted_k(rng)
            steps += 1
        overshoot = position - height
        weight = 2.0 ** (-overshoot)
        total += weight
        total_sq += weight * weight
        total_overshoot += overshoot
        total_steps += steps
        # A bit-length layer is uniform in y=n/2^(p-h) over [1/2,1).
        # Its log-distance is height-log2(y), and multiplying the ruin
        # probability by 2^height contributes y*2^(-overshoot).
        y = 0.5 + 0.5 * rng.random()
        layer_height = height - math.log2(y)
        layer_position = 0.0
        steps = 0
        while layer_position <= layer_height:
            layer_position += log2_3 - tilted_k(rng)
            steps += 1
        layer_overshoot = layer_position - layer_height
        layer_weight = y * (2.0 ** (-layer_overshoot))
        layer_total += layer_weight
        layer_total_sq += layer_weight * layer_weight
        layer_steps += steps
    mean = total / samples
    variance = max(0.0, total_sq / samples - mean * mean)
    layer_mean = layer_total / samples
    layer_variance = max(0.0, layer_total_sq / samples - layer_mean * layer_mean)
    return {
        "height": height,
        "samples": samples,
        "C_RW_estimate": mean,
        "Monte_Carlo_SE": math.sqrt(variance / samples),
        "mean_overshoot": total_overshoot / samples,
        "mean_steps_under_tilt": total_steps / samples,
        "lower_bound_2_over_3": 2.0 / 3.0,
        "layer_averaged_C": layer_mean,
        "layer_averaged_SE": math.sqrt(layer_variance / samples),
        "mean_layer_steps_under_tilt": layer_steps / samples,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--heights", nargs="+", type=float, default=[5, 10, 20, 40])
    parser.add_argument("--samples", type=int, default=100_000)
    parser.add_argument("--seed", type=int, default=20260625)
    parser.add_argument("--out", type=Path, default=Path("outputs/collatz_iid_rw_overshoot.csv"))
    args = parser.parse_args()

    rng = random.Random(args.seed)
    rows = [estimate(height, args.samples, rng) for height in args.heights]
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print("height  C_RW       SE         layer_C    layer_SE   mean_steps")
    for row in rows:
        print(
            f"{float(row['height']):6.1f}  {float(row['C_RW_estimate']):.8f}  "
            f"{float(row['Monte_Carlo_SE']):.8f}  "
            f"{float(row['layer_averaged_C']):.8f}  "
            f"{float(row['layer_averaged_SE']):.8f}  "
            f"{float(row['mean_steps_under_tilt']):.2f}"
        )


if __name__ == "__main__":
    main()
